@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
echo.
echo ==========================================
echo  FPC Server - update
echo ==========================================
echo.

if not exist "update_url.txt" (
  echo [ERROR] update_url.txt not found.
  pause
  exit /b 1
)
set /p UPDATE_URL=<update_url.txt
if not defined UPDATE_URL (
  echo [ERROR] update_url.txt is empty.
  pause
  exit /b 1
)
echo Downloading update from:
echo   %UPDATE_URL%
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$u=(Get-Content -LiteralPath 'update_url.txt' -Raw).Trim();" ^
  "$z=Join-Path $env:TEMP 'fpc-server-update.zip';" ^
  "$d=Join-Path $env:TEMP 'fpc-server-update';" ^
  "Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $z -TimeoutSec 600;" ^
  "if(Test-Path $d){Remove-Item $d -Recurse -Force};" ^
  "New-Item -ItemType Directory -Path $d -Force | Out-Null;" ^
  "Expand-Archive -LiteralPath $z -DestinationPath $d -Force;"
if errorlevel 1 (
  echo [ERROR] Download or unpack failed. Check the link in update_url.txt.
  pause
  exit /b 1
)

echo Installing update...
taskkill /F /IM FPCServer.exe >nul 2>&1
REM Copy only source files and the app; never touch .venv, runtime or node_modules.
xcopy /E /Y /I "%TEMP%\fpc-server-update\app\funpay_price_extension\*" "%~dp0app\funpay_price_extension\" >nul
copy /Y "%TEMP%\fpc-server-update\app\click.py" "%~dp0app\click.py" >nul 2>&1
copy /Y "%TEMP%\fpc-server-update\app\requirements.txt" "%~dp0app\requirements.txt" >nul 2>&1
copy /Y "%TEMP%\fpc-server-update\app\INSTALL_NODE_GGSEL.bat" "%~dp0app\INSTALL_NODE_GGSEL.bat" >nul 2>&1

echo.
echo [OK] Update installed. Starting server...
start "" "%~dp0app\FPCServer.exe"
echo You can close this window.
pause
