@echo off
chcp 65001 >nul
taskkill /F /IM FPCServer.exe >nul 2>&1
for /f "tokens=1" %%P in ('netstat -ano ^| findstr ":8766" ^| findstr "LISTENING"') do taskkill /F /PID %%P >nul 2>&1
echo Server stopped.
timeout /t 2 >nul
exit /b 0
