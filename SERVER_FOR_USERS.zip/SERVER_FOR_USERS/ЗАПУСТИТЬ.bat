@echo off
chcp 65001 >nul
start "" "%~dp0app\FPCServer.exe"
exit /b 0
