@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0app"
echo.
echo ==========================================
echo  FunPay Control Server - installation
echo ==========================================
echo.

rem ---- 1. Find a REAL Python (skip the Microsoft Store stub in WindowsApps) ----
set "PYEXE="
set "PYARGS="
for /f "delims=" %%P in ('where python 2^>nul') do (
  if not defined PYEXE (
    echo/%%P | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
      "%%P" -c "import sys" >nul 2>&1
      if not errorlevel 1 set "PYEXE=%%P"
    )
  )
)
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYEXE (
  py -3.13 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py"
    set "PYARGS=-3.13"
  )
)

rem ---- 2. If not found, download and install Python silently (no admin needed) ----
if not defined PYEXE (
  echo Python not found. Downloading and installing Python 3.13 automatically...
  echo This may take a few minutes. No administrator rights are required.
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop';" ^
    "$u='https://www.python.org/ftp/python/3.13.17/python-3.13.17-amd64.exe';" ^
    "$o=Join-Path $env:TEMP 'fokilan-python-3.13.17-amd64.exe';" ^
    "Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $o -TimeoutSec 600;" ^
    "Start-Process -FilePath $o -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=1','Include_pip=1','AssociateFiles=0','Shortcuts=0' -Wait;"
  if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
  if not defined PYEXE (
    for /f "delims=" %%P in ('where python 2^>nul') do (
      if not defined PYEXE (
        echo/%%P | findstr /i "WindowsApps" >nul
        if errorlevel 1 set "PYEXE=%%P"
      )
    )
  )
  if not defined PYEXE (
    echo [ERROR] Could not install Python automatically.
    echo Check your internet connection and run this file again.
    if not defined FOKILAN_AUTOSTART pause
    exit /b 1
  )
  echo [OK] Python installed: !PYEXE!
)

echo Using Python: !PYEXE! !PYARGS!

rem ---- 3. Virtual environment ----
echo [1/3] Creating virtual environment...
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys" >nul 2>&1
  if errorlevel 1 (
    echo Removing broken virtual environment...
    rmdir /s /q ".venv"
  )
)
if not exist ".venv\Scripts\python.exe" "!PYEXE!" !PYARGS! -m venv .venv
if errorlevel 1 (
  echo [ERROR] Could not create venv with: !PYEXE!
  echo Delete the "app\.venv" folder if it exists, then run again.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)

echo [2/3] Installing Python packages (this may take 10-20 minutes)...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 ( echo [ERROR] Package installation failed. Check your internet. & if not defined FOKILAN_AUTOSTART pause & exit /b 1 )

echo [3/3] Installing Node.js and Playwright...
set "FOKILAN_AUTOSTART=1"
call "%~dp0app\INSTALL_NODE_GGSEL.bat"
if errorlevel 1 ( echo [WARNING] Node/Playwright setup failed - price parsing may not work. )

echo.
echo Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "$d=[Environment]::GetFolderPath('Desktop');" ^
  "$s=$ws.CreateShortcut((Join-Path $d 'FunPay Control Server.lnk'));" ^
  "$s.TargetPath='%~dp0app\FPCServer.exe';" ^
  "$s.WorkingDirectory='%~dp0app';" ^
  "$s.Description='FunPay Control local server';" ^
  "$s.Save()"

echo.
echo [OK] Installation finished. Starting server...
start "" "%~dp0app\FPCServer.exe"
echo.
echo You can close this window. Use the "FunPay Control Server" icon on your desktop.
if not defined FOKILAN_AUTOSTART pause
