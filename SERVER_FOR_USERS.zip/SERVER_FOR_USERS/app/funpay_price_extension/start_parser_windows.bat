﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "EXT=%~dp0"
set "EXT=%EXT:~0,-1%"
for %%I in ("%EXT%\..") do set "PROJECT_ROOT=%%~fI"
set "SERVER=%EXT%\local_server.py"
set "EXPECTED=fokilan-tracker-v1.6.45-ggsel-firefox-cookies-2026-11-07"
set "FOKILAN_PROJECT_ROOT=%PROJECT_ROOT%"

rem Put the project-local portable Node.js first on PATH for this server process.
if exist "%PROJECT_ROOT%\runtime\node.exe" set "PATH=%PROJECT_ROOT%\runtime;%PATH%"
if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%PATH%"
if defined ProgramFiles(x86) if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"

 echo Fokilan Tracker - local server
 echo Project folder: "%PROJECT_ROOT%"
 echo Extension folder: "%EXT%"
 echo Server file: "%SERVER%"
 if not exist "%SERVER%" (
   echo [ERROR] local_server.py was not found: "%SERVER%"
   pause
   exit /b 1
 )

rem If the expected version from this exact project is already running, keep it.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='http://127.0.0.1:8766/health'; try {$r=Invoke-RestMethod -Uri $u -TimeoutSec 2; if($r.ok -and $r.build -eq '%EXPECTED%' -and [string]::Equals([string]$r.root,$env:FOKILAN_PROJECT_ROOT,[StringComparison]::OrdinalIgnoreCase)){Write-Host ('[OK] Correct server already running: '+$r.build) -ForegroundColor Green; if($r.nodeFound){Write-Host ('[OK] Node.js: '+$r.nodePath) -ForegroundColor Green}else{Write-Host '[WARNING] Node.js not found by server. Run INSTALL_NODE_GGSEL.bat.' -ForegroundColor Yellow}; exit 0}} catch {}; exit 1"
if not errorlevel 1 exit /b 0

 echo.
 echo [INFO] Stopping stale local server before restart...
rem Stop a process running this project's local_server.py, regardless of the old build tag.
rem Also stop any listener that holds port 8766 (the dedicated Fokilan local API port).
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $server=[IO.Path]::GetFullPath('%SERVER%'); $pids=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($server,[StringComparison]::OrdinalIgnoreCase) -ge 0 } | ForEach-Object { [int]$_.ProcessId }); $pids += @(Get-NetTCPConnection -LocalPort 8766 -State Listen | Select-Object -ExpandProperty OwningProcess); $pids | Sort-Object -Unique | ForEach-Object { if($_ -ne $PID){Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue} }; Start-Sleep -Milliseconds 900"
rem Fallback for Windows builds where Get-NetTCPConnection is unavailable.
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":8766 .*LISTENING"') do taskkill /F /PID %%P >nul 2>&1

set "PYTHON="
if exist "%PROJECT_ROOT%\.venv\Scripts\python.exe" set "PYTHON=%PROJECT_ROOT%\.venv\Scripts\python.exe"
if not defined PYTHON if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYTHON if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYTHON if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYTHON for /f "delims=" %%P in ('where python.exe 2^>nul') do if not defined PYTHON set "PYTHON=%%P"
if not defined PYTHON (
  echo [ERROR] Python was not found. Install Python 3.11-3.13 and rerun START_FOKILAN.bat.
  pause
  exit /b 1
)

echo Python: "%PYTHON%"
echo Starting the current local server in a minimized window...
start "Fokilan Tracker local server" /min "%PYTHON%" "%SERVER%"

echo Checking that the new server build is active...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$expected='%EXPECTED%'; $project=$env:FOKILAN_PROJECT_ROOT; for($i=0;$i -lt 35;$i++){try{$r=Invoke-RestMethod -Uri 'http://127.0.0.1:8766/health' -TimeoutSec 2; if($r.ok -and $r.build -eq $expected -and [string]::Equals([string]$r.root,$project,[StringComparison]::OrdinalIgnoreCase)){Write-Host ('[OK] Build: '+$r.build) -ForegroundColor Green; if($r.nodeFound){Write-Host ('[OK] Node.js: '+$r.nodePath) -ForegroundColor Green}else{Write-Host '[WARNING] New server is running, but Node.js is not detected. Run INSTALL_NODE_GGSEL.bat.' -ForegroundColor Yellow}; exit 0}; if($r.build){Write-Host ('Waiting for expected build; current response: '+$r.build) -ForegroundColor Yellow}}catch{}; Start-Sleep -Milliseconds 700}; Write-Host 'ERROR: server did not start with the expected build. Check fokilan_server_stderr.log and the minimized server window.' -ForegroundColor Red; exit 1"
if errorlevel 1 (
  echo [ERROR] The expected Fokilan server did not become active.
  echo Check fokilan_server_stderr.log in the project root.
  pause
  exit /b 1
)
echo.
echo [OK] Local server startup completed.
exit /b 0
