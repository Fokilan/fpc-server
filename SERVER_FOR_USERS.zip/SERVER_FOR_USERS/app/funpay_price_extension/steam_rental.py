"""Steam game rental control engine — Fokilan Tracker.

Full flow:
  FunPay order -> pick FREE account linked to that lot -> send credentials to
  buyer chat -> countdown (+5 min entry buffer) -> warning 10 min before end
  -> end message -> seller gets Telegram/desktop notification.

Seller manually rotates the Steam password in browser; stores the new one in
the extension via "Save new password" — subsequent rentals use the saved one.
Email credentials are private: never exposed to buyers.
"""
from __future__ import annotations

import json
import re
import secrets
import string
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "steam_rental.json"
PYSDA_ROOT = ROOT.parent / "pySDA-main"

_ENGINE_LOCK = threading.RLock()
_ENGINE_THREAD = None
_ENGINE_STOP = threading.Event()
_ORDER_RUNNER = None
_ORDER_ACCOUNT = None
_ORDER_ERROR_AT = 0.0
_STATE = {"running": False, "last_error": "", "last_tick": None,
          "checked": 0, "entry_buffer_min": 5, "warning_min": 10}

DEFAULT = {
    "accounts": [], "rentals": [], "lot_offers": {}, "lot_states": {},
    "settings": {
        "entry_buffer_min": 5,       # +5 min to enter the account
        "warning_min": 10,           # warn buyer 10 min BEFORE end
        "default_duration_hours": 24,  # used when the lot title has no duration
        "telegram": True, "sound": True,
        "warning_template": "⏰ Внимание! Аренда '{game}' заканчивается через {time}.\nЗаказ: #{order_id} {order_link}\nЛогин: {login}\nПароль: {password}\nПродлить можно у продавца.",
        "end_template": "✅ Аренда '{game}' завершена.\nЗаказ: #{order_id} {order_link}\nЛогин: {login}\nСпасибо что играли!",
        "deliver_template": "🎮 Аккаунт для аренды '{game}'\nЗаказ: #{order_id} {order_link}\nЛогин: {login}\nПароль: {password}\nСрок: {duration}",
    },
    "duration_patterns": [
        {"re": r"(\d+)\s*(?:ч|час|часа|часов|h|hr)", "unit": "hours"},
        {"re": r"(\d+)\s*(?:д|день|дня|дней|day)", "unit": "days"},
        {"re": r"(\d+)\s*(?:мес|месяц|месяца|месяцев|month)", "unit": "months"},
    ],
    "notifications": [],
}


def _load():
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    for k, v in DEFAULT.items():
        data.setdefault(k, json.loads(json.dumps(v)))
    for k, v in DEFAULT["settings"].items():
        data["settings"].setdefault(k, v)
    for k, v in DEFAULT.items():
        if k != "settings":
            data.setdefault(k, json.loads(json.dumps(v)))
    # migrate legacy templates so order details are always included
    migrated = False
    for key in ("warning_template", "end_template", "deliver_template"):
        if "{order_id}" not in str(data["settings"].get(key, "")):
            data["settings"][key] = DEFAULT["settings"][key]
            migrated = True
    data["_migrated"] = migrated
    return data


def _save(data):
    tmp = DATA_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DATA_FILE)


# ---------- helpers ----------

def parse_duration(title, patterns=None):
    """Return (hours, matched_text) from a FunPay lot title."""
    patterns = patterns or _load()["duration_patterns"]
    text = str(title or "")
    # FunPay lot titles often say "20 минут" — accept minutes even if the
    # saved pattern list predates this support.
    minute_match = re.search(r"(\d+)\s*(?:минут\w*|мин\.?|min\b|m\b)", text, re.I)
    if minute_match:
        try:
            minutes = int(minute_match.group(1))
            if 0 < minutes < 1440:
                return minutes / 60.0, minute_match.group(0)
        except (TypeError, ValueError):
            pass
    for p in patterns:
        m = re.search(p.get("re", ""), text, re.I)
        if not m:
            continue
        try:
            n = int(m.group(1))
        except (TypeError, ValueError):
            continue
        unit = p.get("unit", "hours")
        return n * {"hours": 1, "days": 24, "months": 720}.get(unit, 1), m.group(0)
    return 0, ""


def fmt_duration(hours):
    value = float(hours or 0)
    if 0 < value < 1:
        return f"{int(round(value * 60))} мин"
    hours = int(value)
    if hours >= 720 and hours % 720 == 0:
        return f"{hours // 720} мес"
    if hours >= 24 and hours % 24 == 0:
        return f"{hours // 24} дн"
    return f"{hours} ч"


def fmt_time(seconds):
    seconds = max(0, int(seconds or 0))
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    return (f"{d}д " if d else "") + f"{h:02d}:{m:02d}:{s:02d}"


def mask(value):
    v = str(value or "")
    return v[:2] + "••••" + v[-2:] if len(v) > 5 else "••••"


# ---------- public API ----------

def state():
    with _ENGINE_LOCK:
        d = _load()
        st = dict(_STATE)
        st.update(d["settings"])
        st["active_count"] = sum(1 for r in d["rentals"] if r.get("status") == "active")
        st["free_count"] = len(free_accounts())
        return st


def list_accounts(include_private=False):
    with _ENGINE_LOCK:
        d = _load()
        busy = {str(r.get("account_id")) for r in d["rentals"] if r.get("status") == "active"}
        out = []
        for a in d["accounts"]:
            item = {k: a.get(k) for k in ("id", "login", "game", "lot_ids", "status", "note", "updated_at")}
            item["busy"] = str(a.get("id")) in busy
            item["has_email"] = bool(a.get("email_login") and a.get("email_password"))
            item["has_pw"] = bool(a.get("password"))
            if include_private:
                item["email_login"] = a.get("email_login", "")
                item["email_password"] = a.get("email_password", "")
                item["password"] = a.get("password", "")
            out.append(item)
        return out


def free_accounts():
    with _ENGINE_LOCK:
        d = _load()
        busy = {str(r.get("account_id")) for r in d["rentals"] if r.get("status") == "active"}
        return [a for a in d["accounts"]
                if str(a.get("id")) not in busy and (a.get("status") or "active") == "active"]


def add_account(payload):
    with _ENGINE_LOCK:
        d = _load()
        login = str(payload.get("login") or "").strip()
        if not login or not str(payload.get("password") or "").strip():
            raise ValueError("Укажи логин и пароль Steam.")
        aid = str(payload.get("id") or int(time.time() * 1000))
        acc = {
            "id": aid, "login": login,
            "password": str(payload.get("password") or "").strip(),
            "email_login": str(payload.get("email_login") or "").strip(),
            "email_password": str(payload.get("email_password") or "").strip(),
            "game": str(payload.get("game") or "").strip(),
            "lot_ids": [_extract_lot_id(x) for x in (payload.get("lot_ids") or []) if str(x).strip()],
            "status": "active", "note": str(payload.get("note") or "")[:400],
            "created_at": time.time(), "updated_at": time.time(),
        }
        d["accounts"] = [a for a in d["accounts"] if str(a.get("id")) != aid] + [acc]
        _save(d)
        return {"ok": True, "id": aid, "login": login}


def private_account(aid):
    """Private data — shown ONLY to the seller, never to buyers."""
    with _ENGINE_LOCK:
        d = _load()
        acc = next((a for a in d["accounts"] if str(a.get("id")) == str(aid)), None)
        if not acc:
            raise ValueError("Аккаунт не найден.")
        return {"ok": True, "password": acc.get("password", ""),
                "password_history": acc.get("password_history", []),
                "email_login": acc.get("email_login", ""),
                "email_password": acc.get("email_password", "")}


def update_account(payload):
    with _ENGINE_LOCK:
        d = _load()
        aid = str(payload.get("account_id") or "")
        acc = next((a for a in d["accounts"] if str(a.get("id")) == aid), None)
        if not acc:
            raise ValueError("Аккаунт не найден.")
        for key in ("login", "password", "email_login", "email_password", "game", "note", "status"):
            if key not in payload:
                continue
            value = str(payload[key] or "").strip()
            # Empty secret fields mean "leave unchanged" in the edit form.
            if key in ("password", "email_password", "email_login") and not value:
                continue
            acc[key] = value
        acc["updated_at"] = time.time()
        _save(d)
        return {"ok": True}


def remove_account(aid):
    with _ENGINE_LOCK:
        d = _load()
        d["accounts"] = [a for a in d["accounts"] if str(a.get("id")) != str(aid)]
        _save(d)
        return {"ok": True}


def _extract_lot_id(value):
    """Accept a raw ID or a FunPay URL and return the offer/lot id."""
    v = str(value or "").strip()
    if not v:
        return ""
    if v.isdigit():
        return v
    m = re.search(r"(?:offer|lot|node)(?:_id)?[=/](\d+)", v, re.I) or re.search(r"/(\d+)(?:/|$)", v)
    return m.group(1) if m else v[:80]


def link_account_to_lot(payload):
    with _ENGINE_LOCK:
        d = _load()
        aid = str(payload.get("account_id") or "")
        acc = next((a for a in d["accounts"] if str(a.get("id")) == aid), None)
        if not acc:
            raise ValueError("Аккаунт не найден.")
        lots = [_extract_lot_id(x) for x in (payload.get("lot_ids") or []) if str(x).strip()]
        if "replace" in payload and payload["replace"]:
            acc["lot_ids"] = lots
        else:
            acc["lot_ids"] = list(dict.fromkeys([*(acc.get("lot_ids") or []), *lots]))
        _save(d)
        return {"ok": True, "lot_ids": acc["lot_ids"]}


def list_rentals():
    with _ENGINE_LOCK:
        d = _load()
        out = []
        for r in d["rentals"]:
            item = dict(r)
            end = r.get("ends_at") or 0
            item["remaining"] = fmt_time(end - time.time()) if item.get("status") == "active" else "—"
            out.append(item)
        # active first, then recent ended
        return sorted(out, key=lambda r: (0 if r.get("status") == "active" else 1, -(r.get("started_at") or 0)))[:60]


def start_rental(payload):
    """Pick a free account for the lot and start the countdown."""
    with _ENGINE_LOCK:
        d = _load()
        lot_id = str(payload.get("lot_id") or "").strip()
        lot_title = str(payload.get("lot_title") or "").strip()
        hours, matched = parse_duration(lot_title, d["duration_patterns"])
        if hours <= 0:
            hours = int(payload.get("duration_hours") or 0)
        if hours <= 0:
            hours = int(d["settings"].get("default_duration_hours", 24) or 24)

        acc = next((a for a in d["accounts"] if str(a.get("id")) == str(payload.get("account_id"))), None)
        if not acc:
            candidates = [a for a in free_accounts()
                          if lot_id and lot_id in [str(x) for x in (a.get("lot_ids") or [])]]
            if not candidates and lot_title:
                candidates = [a for a in free_accounts()
                              if a.get("game") and a["game"].lower() in lot_title.lower()]
            if not candidates:
                raise ValueError("Нет свободного аккаунта для этого лота.")
            acc = candidates[0]

        entry = int(d["settings"].get("entry_buffer_min", 5))
        now = time.time()
        rid = str(payload.get("id") or int(now * 1000))
        r = {
            "id": rid, "account_id": str(acc["id"]), "login": acc["login"],
            "game": acc.get("game", ""), "lot_id": lot_id, "lot_title": lot_title[:240],
            "buyer": str(payload.get("buyer") or "")[:120],
            "order_id": str(payload.get("order_id") or "")[:60],
            "offer_id": str(payload.get("offer_id") or "")[:60],
            "order_link": f"https://funpay.com/orders/{str(payload.get('order_id') or '')}/" if payload.get("order_id") else "",
            "chat_node": str(payload.get("chat_node") or "")[:80],
            "duration_hours": hours, "matched": matched,
            "started_at": now,
            "ends_at": now + hours * 3600 + entry * 60,
            "warned": False, "warned_at": None, "notified_end": False,
            "status": "active", "credentials": {"login": acc["login"], "password": acc.get("password", "")},
        }
        d["rentals"] = [x for x in d["rentals"] if str(x.get("id")) != rid] + [r]
        _save(d)
        _notify(r, "start")
        return {"ok": True, "rental": r, "message": _render("deliver_template", r, d)}


def stop_rental(payload):
    with _ENGINE_LOCK:
        d = _load()
        rid = str(payload.get("id") or "")
        r = next((x for x in d["rentals"] if str(x.get("id")) == rid), None)
        if not r:
            raise ValueError("Аренда не найдена.")
        if r.get("status") == "active":
            _finish(r, d, manual=True)
            _save(d)
        return {"ok": True}


def _sync_lot_states():
    """Deactivate/activate rental offers based on free accounts for their lot.

    An offer stays active while at least one account linked to its lot is free.
    Accounts may be linked to several lots, so every watched lot is rechecked.
    """
    try:
        with _ENGINE_LOCK:
            d = _load()
            busy = {str(r.get("account_id")) for r in d["rentals"] if r.get("status") == "active"}
            lot_offers = d.get("lot_offers") or {}
            states = d.get("lot_states") or {}
            changed = False
            for lot_id, offers in lot_offers.items():
                linked = [a for a in d["accounts"]
                          if str(lot_id) in [str(x) for x in (a.get("lot_ids") or [])]]
                free = [a for a in linked if str(a.get("id")) not in busy]
                desired = "active" if free else "inactive"
                for offer_id in offers:
                    key = str(offer_id)
                    if states.get(key) == desired:
                        continue
                    if _set_lot_active(key, desired == "active"):
                        states[key] = desired
                        changed = True
            d["lot_states"] = states
            if changed or d.pop("_migrated", False):
                _save(d)
    except Exception as exc:
        _STATE["last_error"] = "Синхронизация лотов: " + str(exc)[:200]


def _finish(r, cfg, manual=False):
    r["status"] = "ended"
    r["ended_at"] = time.time()
    r["end_reason"] = "manual" if manual else "expired"
    if not r.get("notified_end"):
        _notify(r, "end")
        try:
            send_buyer_message({"rental_id": r["id"], "text": _render("end_template", r, cfg)})
        except Exception:
            pass
        _sync_lot_states()
        r["notified_end"] = True


def save_new_password(payload):
    """Seller changed the Steam password manually — save it for future rentals."""
    with _ENGINE_LOCK:
        d = _load()
        aid = str(payload.get("account_id") or "")
        new_pw = str(payload.get("new_password") or "").strip()
        if not new_pw:
            raise ValueError("Введи новый пароль.")
        acc = next((a for a in d["accounts"] if str(a.get("id")) == aid), None)
        if not acc:
            raise ValueError("Аккаунт не найден.")
        old_pw = str(acc.get("password") or "").strip()
        history = acc.get("password_history") or []
        if old_pw and old_pw != new_pw:
            history = [old_pw] + [x for x in history if x != old_pw]
            acc["password_history"] = history[:10]
        acc["password"] = new_pw
        acc["updated_at"] = time.time()
        d["notifications"].append({"at": time.time(), "type": "password_saved", "account": acc["login"]})
        _save(d)
        return {"ok": True, "login": acc["login"]}


def generate_password():
    alphabet = string.ascii_letters + string.digits + "!@#"
    return "Fk" + "".join(secrets.choice(alphabet) for _ in range(12))


def _render(kind, rental, cfg):
    key = kind if str(kind).endswith("_template") else str(kind) + "_template"
    tpl = cfg["settings"].get(key, "")
    end = rental.get("ends_at") or 0
    order_id = str(rental.get("order_id") or "")
    order_link = f"https://funpay.com/orders/{order_id}/" if order_id else ""
    return (str(tpl)
            .replace("{game}", str(rental.get("game") or ""))
            .replace("{order_id}", order_id)
            .replace("{order_link}", order_link)
            .replace("{lot}", str(rental.get("lot_title") or ""))
            .replace("{login}", str(rental.get("credentials", {}).get("login") or ""))
            .replace("{password}", str(rental.get("credentials", {}).get("password") or ""))
            .replace("{time}", fmt_time(end - time.time()))
            .replace("{duration}", fmt_duration(rental.get("duration_hours")))
            .replace("{buyer}", str(rental.get("buyer") or "")))


def _notify(rental, kind):
    """Telegram notification to the seller + in-extension notification."""
    with _ENGINE_LOCK:
        d = _load()
        d["notifications"].append({
            "at": time.time(), "type": kind, "account": rental.get("login"),
            "game": rental.get("game"), "lot": rental.get("lot_title"),
            "buyer": rental.get("buyer"), "order": rental.get("order_id"),
        })
        _save(d)
    if not d["settings"].get("telegram", True):
        return
    labels = {"start": "▶️ Выдана аренда", "warn": "⏰ Скоро конец аренды",
              "end": "⏹ Аренда завершена", "password_saved": "🔑 Пароль сохранён"}
    text = (f"{labels.get(kind, kind)}: {rental.get('game') or rental.get('lot_title')} · "
            f"покупатель {rental.get('buyer') or '—'} · заказ {rental.get('order_id') or '—'}")
    try:
        cfg = json.loads((ROOT / "telegram_config.json").read_text(encoding="utf-8"))
        import urllib.request
        token, chat = cfg.get("bot_token"), cfg.get("chat_id")
        if token and chat:
            req = urllib.request.Request(
                f"https://api.telegram.org/bot{token}/sendMessage",
                data=json.dumps({"chat_id": chat, "text": text[:4000]}).encode("utf-8"),
                headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=10).read()
    except Exception:
        pass


def notifications(clear=False):
    with _ENGINE_LOCK:
        d = _load()
        items = d["notifications"][-50:]
        if clear:
            d["notifications"] = []
            _save(d)
        return items


def send_buyer_message(payload):
    """Send a templated message to the FunPay buyer chat."""
    rid = str(payload.get("rental_id") or "")
    with _ENGINE_LOCK:
        d = _load()
        r = next((x for x in d["rentals"] if str(x.get("id")) == rid), None)
    if not r:
        raise ValueError("Аренда не найдена.")
    text = str(payload.get("text") or _render("warning_template", r, d))
    node = str(payload.get("chat_node") or r.get("chat_node") or "")
    if not node:
        return {"ok": False, "error": "Неизвестен чат покупателя.", "text": text}
    try:
        import urllib.request
        cfg = json.loads((ROOT / "telegram_config.json").read_text(encoding="utf-8"))
        golden = cfg.get("golden_key")
        if not golden:
            return {"ok": False, "error": "Нет golden_key FunPay.", "text": text}
        req = urllib.request.Request(
            "http://127.0.0.1:8766/api/funpay/send-message",
            data=json.dumps({"golden_key": golden, "chat_id": node, "text": text}).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        res = json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))
        return {"ok": res.get("ok", False), "text": text, "error": res.get("error")}
    except Exception as e:
        return {"ok": False, "error": str(e)[:300], "text": text}


# ---------- engine ----------

def _reconcile_durations():
    """Fix active rentals created before minute-pattern support (24h fallback)."""
    with _ENGINE_LOCK:
        d = _load()
        changed = False
        for r in d["rentals"]:
            if r.get("status") != "active":
                continue
            hours, matched = parse_duration(r.get("lot_title", ""), d["duration_patterns"])
            if hours <= 0 or abs(float(r.get("duration_hours") or 0) - hours) < 0.001:
                continue
            entry = int(d["settings"].get("entry_buffer_min", 5))
            r["duration_hours"] = hours
            r["matched"] = matched
            r["ends_at"] = float(r.get("started_at") or time.time()) + hours * 3600 + entry * 60
            changed = True
        if changed:
            _save(d)


def _tick():
    _reconcile_durations()
    _sync_lot_states()
    try:
        with _ENGINE_LOCK:
            d = _load()
            now = time.time()
            warn_min = int(d["settings"].get("warning_min", 10))
            changed = False
            for r in d["rentals"]:
                if r.get("status") != "active":
                    continue
                end = r.get("ends_at") or 0
                remaining = end - now
                if remaining <= warn_min * 60 and not r.get("warned"):
                    r["warned"] = True
                    r["warned_at"] = now
                    _notify(r, "warn")
                    changed = True
                    try:
                        send_buyer_message({"rental_id": r["id"], "text": _render("warning_template", r, d)})
                    except Exception:
                        pass
                if remaining <= 0:
                    _finish(r, d)
                    changed = True
            if changed:
                _save(d)
        _STATE["last_tick"] = time.time()
        _STATE["checked"] += 1
    except Exception as e:
        _STATE["last_error"] = str(e)[:300]


def _golden_key():
    """Golden Key used by the local server for FunPay sessions."""
    try:
        cfg = json.loads((ROOT / "telegram_config.json").read_text(encoding="utf-8"))
        key = str(cfg.get("golden_key") or "").strip()
        if key:
            return key
    except Exception:
        pass
    return ""


def _record_rental_sale(order, cost=0.0):
    """Feed a real FunPay order into analytics for the profit chart."""
    try:
        import urllib.request
        oid = str(getattr(order, "id", "") or "")
        if not oid:
            return
        title = str(getattr(order, "title", "") or getattr(order, "short_description", "") or "")[:200]
        try:
            sale = float(getattr(order, "sum", 0) or 0)
        except (TypeError, ValueError):
            sale = 0.0
        req = urllib.request.Request(
            "http://127.0.0.1:8766/api/funpay/analytics/record",
            data=json.dumps({
                "lot_id": oid, "lot_title": title,
                "sale_price": sale, "cost_price": float(cost or 0),
                "profit": round(sale - float(cost or 0), 2),
            }).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10).read()
    except Exception:
        pass


def _handle_new_order(order):
    """Create a rental + send credentials for a freshly purchased lot."""
    global _STATE
    oid = str(getattr(order, "id", "") or "")
    if not oid:
        return
    with _ENGINE_LOCK:
        d = _load()
        if any(str(x.get("order_id")) == oid for x in d["rentals"]):
            return  # already delivered
    title = " ".join(str(part or "") for part in (
        getattr(order, "title", None), getattr(order, "short_description", None),
        getattr(order, "full_description", None), getattr(order, "description", None),
    ) if part).strip()[:240]
    buyer = str(getattr(order, "buyer_username", "") or "").strip()
    subcategory = getattr(order, "subcategory", None)
    node_id = str(getattr(subcategory, "id", "") or "")
    node = str(getattr(order, "node", "") or "")
    chat_id = getattr(order, "chat_id", None)
    if not chat_id:
        seller_id = str(getattr(order, "seller_id", "") or getattr(_ORDER_ACCOUNT, "id", "") or "")
        buyer_id = str(getattr(order, "buyer_id", "") or "")
        if seller_id and buyer_id:
            chat_id = f"users-{seller_id}-{buyer_id}"
    lot_ids = [x for x in (node_id, node) if x and x != "None"]
    # только арендные лоты: аккаунт должен быть явно привязан к этому лоту
    linked = [a for a in free_accounts()
              if any(str(x) in [str(v) for v in (a.get("lot_ids") or [])] for x in lot_ids)]
    if not linked:
        return  # ключи, гифты и другие товары не выдаём
    _record_rental_sale(order, 0.0)
    # из HTML заказа достаём ID предложения для деактивации лота
    html = str(getattr(order, "html", "") or "")
    offer_match = re.search(r"(?:offer(?:_id)?[=/]?|offer\?id=)(\d+)", html, re.I)
    offer_id = str(offer_match.group(1)) if offer_match else ""
    rr = None
    last_error = "нет свободного аккаунта для этого лота"
    for lot in lot_ids + [""]:
        try:
            rr = start_rental({
                "lot_id": lot, "lot_title": title, "buyer": buyer,
                "order_id": oid, "chat_node": str(chat_id or node or ""),
                "offer_id": offer_id,
            })
            if rr and rr.get("ok"):
                break
        except Exception as exc:
            last_error = str(exc)[:200]
            rr = None
    if rr and rr.get("ok"):
        sent = send_buyer_message({
            "rental_id": rr["rental"]["id"],
            "text": str(rr.get("message") or ""),
            "chat_node": str(chat_id or node or ""),
        })
        if not sent or not sent.get("ok"):
            err = str((sent or {}).get("error") or "неизвестная ошибка")
            _STATE["last_error"] = "Данные покупателю НЕ отправлены: " + err[:200]
            with _ENGINE_LOCK:
                d = _load()
                d["notifications"].append({
                    "at": time.time(), "type": "delivery_failed",
                    "account": str(rr["rental"].get("login") or ""),
                    "order": oid, "error": err[:200],
                })
                _save(d)
        else:
            _STATE["last_error"] = ""
        with _ENGINE_LOCK:
            d = _load()
            for r in d["rentals"]:
                if str(r.get("order_id")) == oid:
                    if offer_id:
                        r["offer_id"] = offer_id
                    r["order_link"] = f"https://funpay.com/orders/{oid}/"
                    break
            _save(d)
        if offer_id:
            with _ENGINE_LOCK:
                d = _load()
                lots = d.setdefault("lot_offers", {})
                for lot in lot_ids:
                    current = [str(x) for x in (lots.get(lot) or [])]
                    if offer_id not in current:
                        current.append(offer_id)
                    lots[lot] = current
                _save(d)
            _sync_lot_states()
    else:
        _STATE["last_error"] = "Заказ " + oid + ": " + last_error


def _poll_orders():
    """Poll FunPay for NEW_ORDER events independently of the AI worker."""
    global _ORDER_RUNNER, _ORDER_ACCOUNT, _ORDER_ERROR_AT
    key = _golden_key()
    if not key:
        if time.time() - _ORDER_ERROR_AT > 60:
            _STATE["last_error"] = "Нет Golden Key FunPay — заказы не опрашиваются"
            _ORDER_ERROR_AT = time.time()
        return
    try:
        if _ORDER_RUNNER is None:
            maker = globals().get("_make_runner")
            if maker is not None:
                _ORDER_ACCOUNT, _ORDER_RUNNER = maker(key)
            else:
                from FunPayAPI import Account, Runner
                acc = Account(golden_key=key).get()
                runner = Runner(acc, disable_message_requests=True, disabled_order_requests=False)
                runner.parse_updates(runner.get_updates())  # initialize snapshots
                _ORDER_ACCOUNT = acc
                _ORDER_RUNNER = runner
            _STATE["last_error"] = ""
            return
        events = _ORDER_RUNNER.parse_updates(_ORDER_RUNNER.get_updates())
        from FunPayAPI import enums
        for event in events or []:
            if getattr(event, "type", None) != getattr(enums.EventTypes, "NEW_ORDER", None):
                continue
            order = getattr(event, "order", None)
            if order is not None:
                _handle_new_order(order)
    except Exception as exc:
        _STATE["last_error"] = "Опрос заказов: " + str(exc)[:200]
        _ORDER_RUNNER = None
        _ORDER_ACCOUNT = None
        _ORDER_ERROR_AT = time.time()


def _worker():
    while not _ENGINE_STOP.wait(10):
        _tick()
        _poll_orders()


def start_engine():
    with _ENGINE_LOCK:
        if _STATE["running"]:
            return {"ok": True, "already": True}
        _ENGINE_STOP.clear()
        threading.Thread(target=_worker, daemon=True, name="fokilan-rental").start()
        _STATE.update(running=True, last_error="")
        return {"ok": True}


def stop_engine():
    with _ENGINE_LOCK:
        _ENGINE_STOP.set()
        _STATE["running"] = False
        return {"ok": True}


def get_settings():
    return _load()["settings"]


def save_settings(payload):
    with _ENGINE_LOCK:
        d = _load()
        allowed = ("entry_buffer_min", "warning_min", "default_duration_hours", "telegram", "sound",
                   "deliver_template", "warning_template", "end_template")
        for k in allowed:
            if k in payload:
                d["settings"][k] = payload[k]
        _save(d)
        return {"ok": True, "settings": d["settings"]}
