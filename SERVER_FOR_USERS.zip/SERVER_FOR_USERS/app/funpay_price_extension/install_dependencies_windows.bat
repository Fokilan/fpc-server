@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0\.."
set "PROJECT=%CD%"
set "VENV_PY=%PROJECT%\.venv\Scripts\python.exe"
set "BASE_PY="

echo Fokilan Tracker - repair Python environment and install dependencies
echo Project folder: "%PROJECT%"
echo.

rem Reuse a working virtual environment. Rebuild it if its base Python was removed.
if exist "%VENV_PY%" (
  "%VENV_PY%" -c "import sys; print(sys.executable)" >nul 2>&1
  if not errorlevel 1 goto venv_found
)

echo [1/4] Finding an installed Python 3.11, 3.12, or 3.13...
call :find_base_python
if not defined BASE_PY (
  echo.
  echo [ERROR] A working Python 3.11, 3.12, or 3.13 installation was not found.
  echo Install Python from https://www.python.org/downloads/windows/
  echo During installation, enable the Python Launcher and/or "Add python.exe to PATH".
  echo Then run this file again.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)
echo Using base Python: "%BASE_PY%"

if exist "%PROJECT%\.venv" (
  echo The old .venv is broken or points to a removed Python. Recreating it...
  rmdir /s /q "%PROJECT%\.venv"
  if exist "%PROJECT%\.venv" (
    echo [ERROR] Could not remove the broken .venv folder. Close programs using it and try again.
    if not defined FOKILAN_AUTOSTART pause
    exit /b 1
  )
)
"%BASE_PY%" -m venv "%PROJECT%\.venv"
if errorlevel 1 (
  echo [ERROR] Could not create the virtual environment.
  echo Check that the Python installation includes pip and venv.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)

:venv_found
if not exist "%VENV_PY%" (
  echo [ERROR] Virtual environment Python was not created: "%VENV_PY%"
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)
"%VENV_PY%" -c "import sys; print(sys.version)"
if errorlevel 1 (
  echo [ERROR] The virtual environment still cannot run. Check the installed Python version.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)

echo.
echo [2/4] Installing project dependencies. This step needs internet access...
"%VENV_PY%" -m ensurepip --upgrade >nul 2>&1
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto fail
"%VENV_PY%" -m pip install -r "%PROJECT%\requirements.txt"
if errorlevel 1 goto fail
"%VENV_PY%" -m pip install -r "%PROJECT%\funpay_price_extension\requirements-funpay-parser.txt"
if errorlevel 1 goto fail

echo.
echo [3/4] Verifying Python packages and dependency compatibility...
"%VENV_PY%" -c "import requests, bs4, FunPayAPI, funpayparsers, eventry; from importlib.metadata import version; from packaging.version import Version; print('requests=' + version('requests')); print('FunPayAPI=' + version('FunPayAPI')); print('funpaybotengine=' + version('funpaybotengine')); print('funpayparsers=' + version('funpayparsers')); print('eventry=' + version('eventry')); assert version('requests') == '2.28.1', 'Expected requests==2.28.1'; assert version('FunPayAPI') == '1.1.0', 'Expected FunPayAPI==1.1.0'; assert version('funpaybotengine') == '0.6.0', 'Expected funpaybotengine==0.6.0'; assert version('funpayparsers') == '0.7.0', 'Expected funpayparsers==0.7.0'; assert version('eventry') == '0.3.6', 'Expected eventry==0.3.6'; import eventry.asyncio.default_types; import funpaybotengine; print('[OK] Versions match and eventry compatibility import passed')"
if errorlevel 1 goto fail
"%VENV_PY%" -m pip check
if errorlevel 1 (
  echo [ERROR] pip found conflicting installed dependencies. See the conflict above.
  goto fail
)

echo.
echo [4/4] Checking Node.js and the GGSEL Playwright collector...
if exist "%PROJECT%\runtime\node.exe" set "PATH=%PROJECT%\runtime;%PATH%"
if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%PATH%"
if defined ProgramFiles(x86) if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"
where node.exe >nul 2>&1
if errorlevel 1 (
  echo Node.js was not found. Installing a project-local runtime and Playwright...
  set "FOKILAN_AUTOSTART=1"
  call "%PROJECT%\INSTALL_NODE_GGSEL.bat"
  set "NODE_SETUP_RESULT=%ERRORLEVEL%"
  set "FOKILAN_AUTOSTART="
  if not "%NODE_SETUP_RESULT%"=="0" (
    echo [WARNING] Node.js setup failed. See the error above and run INSTALL_NODE_GGSEL.bat manually.
    goto success
  )
)
if exist "%PROJECT%\runtime\node.exe" set "PATH=%PROJECT%\runtime;%PATH%"
where node.exe >nul 2>&1
if errorlevel 1 (
  echo [WARNING] Node.js remains unavailable. The Python server can run, but GGSEL parsing cannot.
  goto success
)
if not exist "%PROJECT%\ggsel_plati\node_modules\playwright\package.json" (
  where npm.cmd >nul 2>&1
  if errorlevel 1 (
    echo [WARNING] npm was not found. Could not install the GGSEL collector package.
    goto success
  )
  call npm.cmd install --prefix "%PROJECT%\ggsel_plati" --no-audit --no-fund
  if errorlevel 1 (
    echo [WARNING] npm install failed. The server can still run, but the GGSEL collector may fail.
    goto success
  )
)
if exist "%PROJECT%\ggsel_plati\node_modules\.bin\playwright.cmd" (
  echo Checking/downloading Chromium for the GGSEL collector...
  call "%PROJECT%\ggsel_plati\node_modules\.bin\playwright.cmd" install chromium
  if errorlevel 1 echo [WARNING] Chromium setup failed; GGSEL parsing may not work until it is installed.
) else (
  echo [WARNING] Playwright CLI was not found in ggsel_plati\node_modules.
)

goto success

:find_base_python
set "BASE_PY="
for %%V in (3.13 3.12 3.11) do call :try_launcher %%V
if defined BASE_PY exit /b 0
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%ProgramFiles%\Python313\python.exe" "%ProgramFiles%\Python312\python.exe" "%ProgramFiles%\Python311\python.exe") do call :try_path "%%~P"
if defined BASE_PY exit /b 0
for /f "delims=" %%P in ('where python.exe 2^>nul') do call :try_path "%%P"
exit /b 0

:try_launcher
if defined BASE_PY exit /b 0
py -%~1 -c "import sys; print(sys.executable)" >nul 2>&1
if errorlevel 1 exit /b 0
for /f "delims=" %%P in ('py -%~1 -c "import sys; print(sys.executable)" 2^>nul') do set "BASE_PY=%%P"
exit /b 0

:try_path
if defined BASE_PY exit /b 0
if not exist "%~1" exit /b 0
"%~1" -c "import sys; raise SystemExit(0 if (3,11) <= sys.version_info[:2] < (3,14) else 1)" >nul 2>&1
if not errorlevel 1 set "BASE_PY=%~1"
exit /b 0

:success
echo.
echo [OK] Dependency compatibility check passed.
echo Use START_FOKILAN.bat in the main project folder to launch Fokilan Tracker.
if not defined FOKILAN_AUTOSTART pause
exit /b 0

:fail
echo.
echo [ERROR] Dependency installation or verification failed. Read the error above.
echo If pip reports a conflict, send the complete text from this window.
if not defined FOKILAN_AUTOSTART pause
exit /b 1
