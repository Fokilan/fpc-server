@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
set "PROJECT=%CD%"
set "RUNTIME=%PROJECT%\runtime"
set "FOKILAN_NODE_RUNTIME=%PROJECT%\runtime"
set "FOKILAN_PROJECT=%PROJECT%"
set "COLLECTOR=%PROJECT%\ggsel_plati"

echo Fokilan Tracker - Node.js / GGSEL collector repair
echo Project: "%PROJECT%"
echo.

if not exist "%RUNTIME%" mkdir "%RUNTIME%" >nul 2>&1
call :use_runtime
if defined NODE_EXE goto node_ready
for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if defined NODE_EXE goto node_ready

echo [1/3] Downloading portable Node.js 24 LTS into the project runtime...
echo No administrator permissions are required. An internet connection is required.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $items=$null; $last=$null; foreach($indexUri in @('https://nodejs.org/dist/index.json','https://npmmirror.com/mirrors/node/index.json')) { try { $items=Invoke-RestMethod -Uri $indexUri -TimeoutSec 20; if($items){break} } catch { $last=$_ } }; if(-not $items){throw ('Could not download Node.js version list. '+$last)}; $item=$items | Where-Object { $_.version -like 'v24.*' -and $_.lts -and $_.version -match '^v\d+\.\d+\.\d+$' } | Select-Object -First 1; if(-not $item){$item=$items | Where-Object { $_.version -like 'v24.*' -and $_.version -match '^v\d+\.\d+\.\d+$' } | Select-Object -First 1}; if(-not $item){throw 'No Node.js 24 Windows release was found in the index.'}; $ver=$item.version; $archiveName='node-'+$ver+'-win-x64.zip'; $zip=Join-Path $env:TEMP 'fokilan-node-win-x64.zip'; $tmp=Join-Path $env:TEMP 'fokilan-node-unpack'; if(Test-Path $tmp){Remove-Item -LiteralPath $tmp -Recurse -Force}; New-Item -ItemType Directory -Path $tmp -Force | Out-Null; $downloaded=$false; foreach($base in @('https://nodejs.org/dist/','https://npmmirror.com/mirrors/node/')) { try { $url=$base+$ver+'/'+$archiveName; Write-Host ('Trying '+$url); Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip -TimeoutSec 120; if((Get-Item $zip).Length -lt 1000000){throw 'Downloaded archive is unexpectedly small.'}; $downloaded=$true; break } catch { Write-Host ('Download failed: '+$_.Exception.Message); Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue } }; if(-not $downloaded){throw 'Could not download the official Node.js Windows ZIP from either mirror.'}; Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force; $node=Get-ChildItem -LiteralPath $tmp -Filter 'node.exe' -File -Recurse | Select-Object -First 1; if(-not $node){throw 'node.exe was not found in the downloaded archive.'}; $src=$node.Directory.FullName; $dest=$env:FOKILAN_NODE_RUNTIME; New-Item -ItemType Directory -Path $dest -Force | Out-Null; Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force; if(-not (Test-Path (Join-Path $dest 'node.exe'))){throw 'Copying node.exe failed.'}; & (Join-Path $dest 'node.exe') --version; Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue"
if errorlevel 1 (
  echo.
  echo [ERROR] Node.js download failed. Check internet access to nodejs.org and npmmirror.com.
  echo You can also install Node.js LTS manually from https://nodejs.org/ and rerun this file.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)

:node_ready
call :use_runtime
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE (
  echo [ERROR] node.exe still cannot be found or started.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)
set "FOKILAN_NODE_PATH=%NODE_EXE%"
set "PATH=%RUNTIME%;%PATH%"
echo [OK] Node.js: "%NODE_EXE%"
"%NODE_EXE%" --version

if not exist "%COLLECTOR%" mkdir "%COLLECTOR%" >nul 2>&1
if not exist "%COLLECTOR%\package.json" (
  >"%COLLECTOR%\package.json" echo {"name":"fokilan-ggsel-collector","private":true}
)

rem Install Playwright explicitly instead of relying on a pre-existing package.json.
if not exist "%COLLECTOR%\node_modules\playwright\package.json" (
  echo.
  echo [2/3] Installing the Playwright package into ggsel_plati\node_modules...
  where npm.cmd >nul 2>&1
  if errorlevel 1 if exist "%RUNTIME%\npm.cmd" set "PATH=%RUNTIME%;%PATH%"
  where npm.cmd >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] npm.cmd was not found next to Node.js.
    if not defined FOKILAN_AUTOSTART pause
    exit /b 1
  )
  call npm.cmd install --prefix "%COLLECTOR%" playwright --no-audit --no-fund
  if errorlevel 1 (
    echo [ERROR] npm install Playwright failed. Check the internet connection and retry.
    if not defined FOKILAN_AUTOSTART pause
    exit /b 1
  )
) else (
  echo [2/3] Playwright package is already installed.
)

if not exist "%COLLECTOR%\node_modules\playwright\package.json" (
  echo [ERROR] Playwright package is still missing after npm install.
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)
echo.
echo [3/3] Installing/checking Chromium for Playwright...
if exist "%COLLECTOR%\node_modules\.bin\playwright.cmd" (
  call "%COLLECTOR%\node_modules\.bin\playwright.cmd" install chromium
  if errorlevel 1 (
    echo [ERROR] Playwright Chromium setup failed. Check network access and rerun this file.
    if not defined FOKILAN_AUTOSTART pause
    exit /b 1
  )
) else (
  echo [ERROR] Playwright CLI was not found under "%COLLECTOR%\node_modules\.bin".
  if not defined FOKILAN_AUTOSTART pause
  exit /b 1
)

echo.
echo [OK] Node.js, Playwright, and Chromium are ready.
echo Now run START_FOKILAN.bat again so the local Python server restarts with the new Node detection.
if not defined FOKILAN_AUTOSTART pause
exit /b 0

:use_runtime
set "NODE_EXE="
if exist "%RUNTIME%\node.exe" (
  "%RUNTIME%\node.exe" --version >nul 2>&1
  if not errorlevel 1 set "NODE_EXE=%RUNTIME%\node.exe"
)
if not defined NODE_EXE if exist "%RUNTIME%\node-v24-win-x64\node.exe" (
  "%RUNTIME%\node-v24-win-x64\node.exe" --version >nul 2>&1
  if not errorlevel 1 set "NODE_EXE=%RUNTIME%\node-v24-win-x64\node.exe"
)
exit /b 0
