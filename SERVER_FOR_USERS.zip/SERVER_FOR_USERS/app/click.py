#!/usr/bin/env node
// Z.ai / GLM Coding variant price collector — Plati + GGSEL
// Pass 1: N parallel Playwright workers. Multi-template aware.
// Pass 2 (zai_analyze.py) interprets.
//
// Run:
//   node zai_price_scanner.js [--workers=6] [--out=/tmp/zai_raw.json]

const path = require('path');
const fs = require('fs');
const { chromium } = require(
  fs.existsSync(path.join(__dirname, 'ggsel_plati', 'node_modules', 'playwright'))
    ? path.join(__dirname, 'ggsel_plati', 'node_modules', 'playwright')
    : 'playwright',
);

const CHROME_PATH = String(process.env.CHROME_PATH || '').trim();

// Populated via --plati-pids / --ggsel-ids CLI args. Empty defaults.
const PLATI_PIDS = [];
const GGSEL_IDS = [];

// Parse --key=value OR --key value (next must not start with --)
const argv = process.argv.slice(2);
const args = {};
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (!a.startsWith('--')) continue;
  let key, value;
  const eq = a.indexOf('=');
  if (eq >= 0) {
    key = a.slice(2, eq);
    value = a.slice(eq + 1);
  } else {
    key = a.slice(2);
    const next = argv[i + 1];
    if (next !== undefined && !next.startsWith('--')) {
      value = next;
      i++;
    } else {
      value = true;
    }
  }
  args[key] = value;
}
// Optional exact product URL map. Keep path/query parameters instead of rebuilding a bare ID URL.
let GGSEL_URL_MAP = {};
if (args['ggsel-url-map']) {
  try { GGSEL_URL_MAP = JSON.parse(fs.readFileSync(String(args['ggsel-url-map']), 'utf8')); }
  catch (e) { process.stderr.write(`Could not read --ggsel-url-map: ${e.message || e}\n`); }
}
let GGSEL_COOKIES = [];
if (args['ggsel-cookies']) {
  try {
    const value = JSON.parse(fs.readFileSync(String(args['ggsel-cookies']), 'utf8'));
    if (Array.isArray(value)) {
      GGSEL_COOKIES = value.filter(cookie => cookie &&
        typeof cookie.name === 'string' && cookie.name &&
        typeof cookie.value === 'string' &&
        typeof cookie.domain === 'string' &&
        /(?:^|\.)ggsel\.net$/i.test(cookie.domain.replace(/^\./, ''))
      ).slice(0, 80);
    }
  } catch (e) {
    process.stderr.write(`Could not read --ggsel-cookies: ${e.message || e}\n`);
  }
}
// Merge --plati-pids / --ggsel-ids (comma-separated) into the empty defaults
if (args['plati-pids']) {
  for (const p of String(args['plati-pids']).split(',').map((s) => Number(s.trim())).filter(Boolean)) {
    if (!PLATI_PIDS.includes(p)) PLATI_PIDS.push(p);
  }
}
if (args['ggsel-ids']) {
  for (const id of String(args['ggsel-ids']).split(',').map((s) => s.trim()).filter(Boolean)) {
    if (!GGSEL_IDS.includes(id)) GGSEL_IDS.push(id);
  }
}
const WORKERS = Number(args.workers || 6);
const OUT_PATH = args.out || '/tmp/zai_raw.json';
const PAGE_TIMEOUT_MS = Number(args['page-timeout'] || 35000);
const CLICK_TIMEOUT_MS = Number(args['click-timeout'] || 8000);
const PRICE_SETTLE_TIMEOUT_MS = Number(args['price-settle-timeout'] || 5000);
const CAPTURE_RETRIES = Number(args['capture-retries'] || 2);
const VARIANT_HINT = String(args.variant || '').trim();
const DISCOVER_ONLY = args['discover-only'] === true || String(args['discover-only'] || '').toLowerCase() === 'true';
const FAST_GGSEL = args['fast-ggsel'] === true || String(args['fast-ggsel'] || '').toLowerCase() === 'true';
// Production requests from the extension explicitly use --headless. Discovery
// reads option labels only; it must never click every option or perform retries.
const HEADLESS = args.headless === true || args.headless === 'true' || GGSEL_IDS.length === 0;
// Optional connection to an already-open, user-authenticated Chrome started
// with --remote-debugging-port. Useful when a marketplace disables reactive
// product controls in an isolated automation profile.
const CDP_URL = String(args['cdp-url'] || process.env.MARKETPLACE_CDP_URL || '').trim();

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

process.on('uncaughtException', (e) => process.stderr.write(`UNCAUGHT: ${e.stack || e}\n`));
process.on('unhandledRejection', (e) => process.stderr.write(`UNHANDLED: ${e?.stack || e}\n`));

// ---- Output file management (incremental writes) ------------------------

fs.writeFileSync(OUT_PATH, JSON.stringify({
  schemaVersion: 2,
  startedAt: new Date().toISOString(),
  note: 'Pass 1 raw. zai_analyze.py interprets.',
  config: {
    workers: WORKERS,
    pageTimeoutMs: PAGE_TIMEOUT_MS,
    clickTimeoutMs: CLICK_TIMEOUT_MS,
    priceSettleTimeoutMs: PRICE_SETTLE_TIMEOUT_MS,
    captureRetries: CAPTURE_RETRIES,
  },
  listings: [],
}, null, 2));

const appendListing = (r) => {
  const cur = JSON.parse(fs.readFileSync(OUT_PATH, 'utf8'));
  cur.listings.push(r);
  cur.lastUpdate = new Date().toISOString();
  fs.writeFileSync(OUT_PATH, JSON.stringify(cur, null, 2));
};

// ---- All page-evaluate bodies share these helpers (scoped inside the fn) -

const PAGE_FN = `
let REQUESTED_VARIANT_HINT = '';
let REQUESTED_VARIANT_WORDS = [];
const controlVisible = (el) => {
  if (!el) return false;
  try {
    if (!el.getClientRects().length) return false;
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      if (node.hidden || node.hasAttribute('inert') || node.getAttribute('aria-hidden') === 'true') return false;
      const st = window.getComputedStyle(node);
      if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity || 1) <= 0.01) return false;
      if (node === document.documentElement) break;
    }
    return true;
  } catch (_) { return false; }
};
const isInPurchaseArea = (el) => Boolean(el && el.closest && el.closest('[class*="ProductBuyBlock"], [class*="BuyBlock"], [class*="buyBlock"], [class*="product-buy"], [data-testid*="buy" i], [data-testid*="product-buy" i]'));
const findElement = (tag, text, exact, ctrl = null) => {
  const selectors = {
    button: 'button', label: 'label', radio: 'input[type="radio"]',
    'role-radio': '[role="radio"]', 'role-button': '[role="button"]',
    'role-option': '[role="option"]', link: 'a[href]',
    'select-option': 'select option', 'data-option': '[data-value],[data-label],[data-option],[data-variant]',
    generic: (ctrl && ctrl.elementTag && /^[a-z][a-z0-9-]*$/i.test(ctrl.elementTag)) ? ctrl.elementTag : 'div,span,li,p'
  };
  const selector = selectors[tag]; if (!selector) return null;
  const wanted = String(text || '').replace(/\\s+/g, ' ').trim();
  let matches = Array.from(document.querySelectorAll(selector)).filter(el => {
    if (!controlVisible(el)) return false;
    if (tag === 'data-option' && ctrl && ctrl.dataAttribute && ctrl.dataValue != null && el.getAttribute(ctrl.dataAttribute) !== String(ctrl.dataValue)) return false;
    const visibleEl = tag === 'radio' ? (el.closest('label') || el) : el;
    const actual = tag === 'select-option' ? (el.textContent || '') : (visibleEl.innerText || visibleEl.textContent || '');
    const normalized = String(actual).replace(/\\s+/g, ' ').trim();
    if (!(exact ? normalized === wanted : normalized.startsWith(wanted))) return false;
    if (tag === 'generic' && ctrl) {
      const actualClass = String(el.className && el.className.baseVal || el.className || '').trim();
      const actualId = String(el.id || '');
      if (ctrl.elementId && actualId && actualId !== String(ctrl.elementId)) return false;
      const expectedClasses = String(ctrl.elementClass || '').split(/\\s+/).filter(Boolean);
      if (expectedClasses.length && actualClass && !expectedClasses.some(token => actualClass.split(/\\s+/).includes(token))) return false;
    }
    return true;
  });
  if (matches.length > 1) {
    if (tag === 'generic' && ctrl) {
      const score = el => {
        let n = 0;
        const cls = String(el.className && el.className.baseVal || el.className || '');
        if (ctrl.elementId && String(el.id || '') === String(ctrl.elementId)) n += 200;
        if (ctrl.elementClass && cls === String(ctrl.elementClass)) n += 100;
        if (/(variant|option|region|country|edition|parameter|selector|choice|switch|tab|вариант|регион|страна|издани|параметр)/i.test(cls)) n += 30;
        let parent = el.parentElement;
        for (let depth=0; parent && depth<6 && parent!==document.body; parent=parent.parentElement,depth++) {
          const pt = String(parent.innerText || parent.textContent || '').replace(/\\s+/g,' ').trim();
          if (!pt || pt.length > 2300) break;
          const chips = Array.from(parent.querySelectorAll('div,span,li,p,button,a[href],[role="option"],[role="radio"],label'))
            .filter(child => {
              if (!controlVisible(child)) return false;
              const ct = String(child.innerText || child.textContent || '').replace(/\\s+/g,' ').trim();
              return ct.length >= 2 && ct.length <= 220 && /(Russia|Россия|Ukraine|Украин|\\bUA\\b|Belarus|Беларус|СНГ|CIS|Kazakhstan|Казахстан|Turkey|Турци|Argentina|Аргентин|India|Индия|China|Китай|США|USA|Europe|Европ|Philippin|Филипп|Deluxe|Standard|Vault|издани|регион|страна)/i.test(ct) && !Array.from(child.children || []).some(grand => String(grand.innerText || grand.textContent || '').replace(/\\s+/g,' ').trim() === ct);
            });
          const unique = new Set(chips.map(ch => String(ch.innerText || ch.textContent || '').replace(/\\s+/g,' ').trim().toLowerCase()));
          if (unique.size >= 3 && /(?:выберите|выбрать|select|choose)\\s*.{0,36}(?:регион|стран|издани|вариант|region|country|edition|variant)/i.test(pt)) { n += 120; break; }
          if (unique.size >= 4) { n += 80; break; }
        }
        if (isInPurchaseArea(el)) n += 10;
        return n;
      };
      matches.sort((a,b) => score(b)-score(a));
      if (matches.length > 1 && score(matches[0]) === score(matches[1])) return null;
    } else {
      const purchaseMatches = matches.filter(isInPurchaseArea);
      if (purchaseMatches.length) matches = purchaseMatches;
    }
  }
  if (matches.length !== 1) return null;
  const el = matches[0]; return tag === 'radio' ? (el.closest('label') || el) : el;
};

const findElementByIndex = (tag, index) => {
  if (!Number.isInteger(index) || index < 0) return null;
  let pool;
  if (tag === 'button') pool = document.querySelectorAll('button');
  else if (tag === 'label') pool = document.querySelectorAll('label');
  else if (tag === 'radio') pool = document.querySelectorAll('input[type="radio"]');
  else if (tag === 'role-radio') pool = document.querySelectorAll('[role="radio"]');
  else if (tag === 'role-button') pool = document.querySelectorAll('[role="button"]');
  else if (tag === 'role-option') pool = document.querySelectorAll('[role="option"]');
  else if (tag === 'link') pool = document.querySelectorAll('a[href]');
  else if (tag === 'select-option') pool = document.querySelectorAll('select option');
  else return null;
  return pool[index] || null;
};

const fireClick = (el) => {
  if (!el) return;
  el.scrollIntoView({ block: 'center' });
  const rect = el.getBoundingClientRect();
  for (const ev of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
    el.dispatchEvent(new MouseEvent(ev, {
      bubbles: true, cancelable: true, view: window,
      clientX: rect.x + rect.width / 2, clientY: rect.y + rect.height / 2, button: 0,
    }));
  }
  // Also dispatch a change event on any associated input — required by
  // Plati single-select accordion: radios do not fire change automatically
  // when the wrapping label is clicked programmatically.
  const input = (el.tagName === 'LABEL') ? el.querySelector('input[type="radio"], input[type="checkbox"]') : null;
  const target = input || el.querySelector('input[type="radio"]');
  if (target) {
    target.dispatchEvent(new Event('change', { bubbles: true }));
    target.dispatchEvent(new Event('input', { bubbles: true }));
    if (target.checked !== true && target.type === 'radio') target.checked = true;
  }
};

const isSelectedElement = (el, text) => {
  if (!el) return false;
  const input = el.matches && el.matches('input, option')
    ? el
    : el.querySelector && el.querySelector('input[type="radio"], input[type="checkbox"], option');
  if (el.checked || el.selected || (input && (input.checked || input.selected))) return true;
  const selectedAttrs = ['aria-checked', 'aria-selected', 'aria-pressed', 'aria-current', 'data-selected', 'data-active', 'data-checked', 'data-state'];
  const stateOnNode = node => {
    if (!node) return false;
    // aria-checked on role="radio" / input inside — GGSEL pattern
    const ariaChecked = node.getAttribute && node.getAttribute('aria-checked') === 'true';
    if (ariaChecked) return true;
    const roleRadio = node.matches && (node.matches('[role="radio"]') || node.querySelector('[role="radio"]'));
    if (roleRadio) {
      const inner = node.querySelector('[role="radio"]') || node;
      if (inner.getAttribute && inner.getAttribute('aria-checked') === 'true') return true;
    }
    for (const name of selectedAttrs) {
      const value = String(node.getAttribute && node.getAttribute(name) || '').toLowerCase();
      if (['true','checked','selected','active','current','1'].includes(value)) return true;
    }
    const cls = String(node.className && node.className.baseVal || node.className || '').toLowerCase().split(/\s+/).filter(Boolean);
    const negative = cls.some(token => /(^|[-_])(not|unselected|deselected|inactive|disabled)([-_]|$)/.test(token));
    const positive = cls.some(token => /^(active|selected|checked|chosen|current|is-active|is-selected)$/.test(token) || /(^|[-_])(active|selected|checked|chosen|current)([-_]|$)/.test(token));
    return positive && !negative;
  };
  const normalizeOptionText = value => String(value || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase('ru').replace(/ё/g, 'е');
  const wantedOptionText = normalizeOptionText(text || (el.innerText || el.textContent || ''));
  for (let node=el, depth=0; node && depth<5 && node.nodeType === 1; node=node.parentElement,depth++) {
    const nodeText = normalizeOptionText(node.innerText || node.textContent || '');
    // Selected state is often applied to a wrapper around the visible label.
    // Only trust a wrapper when its complete text is exactly this option; never
    // infer selection from the entire region/edition group container.
    const sameOptionWrapper = depth === 0 || (wantedOptionText && nodeText === wantedOptionText);
    if (sameOptionWrapper && stateOnNode(node)) return true;
    if (node.matches && node.matches('[class*="ProductBuyBlock"], [class*="BuyBlock"], [class*="buyBlock"]')) break;
    if (depth > 0) {
      // A wrapper that contains several independent choices is a group, not
      // this option. We have already checked it only if its text exactly matched.
      const choices = node.querySelectorAll && node.querySelectorAll('button,a[href],[role="button"],[role="radio"],[role="option"],label,input[type="radio"],input[type="checkbox"],[data-value],[data-option],[data-variant],[tabindex]');
      if (!sameOptionWrapper || (choices && choices.length > 1)) break;
    }
  }
  const selectedText = /(?:^|\\s)(?:выбран(?:о|а)?|selected)(?:\\s|$)/i.test(text || '');
  return selectedText;
};

const isUnavailableText = (text) =>
  /нет\\s+в\\s+наличии|нет\\s+в\\s+продаже|недоступ|законч|распродан|out\\s+of\\s+stock|sold\\s+out|unavailable|not\\s+available/i.test(text || '');

const snapshotPrices = () => {
  const hiddenTree = (el) => {
    try {
      for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
        if (node.hidden || node.hasAttribute('inert') || node.getAttribute('aria-hidden') === 'true') return true;
        const style = window.getComputedStyle(node);
        if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) <= 0.01) return true;
        if (node === document.documentElement) break;
      }
      return false;
    } catch (_) { return true; }
  };
  const visibleNow = (el) => Boolean(el && el.getClientRects().length && !hiddenTree(el));
  const normalizeText = (value) => String(value || '').replace(/\\s+/g, ' ').trim();
  const isRubPrice = (value) => {
    const t = normalizeText(value);
    return t.length > 0 && t.length < 40 && /^\\d[\\d\\s\\u00a0\\u202f.,]*\\s*(?:₽|руб(?:\\.|лей|ля)?|RUB)\\s*$/i.test(t);
  };
  const textOf = (el) => {
    if (!el) return '';
    const inner = normalizeText(el.innerText);
    const content = normalizeText(el.textContent);
    if (isRubPrice(inner)) return inner;
    if (isRubPrice(content)) return content;
    return inner || content;
  };
  const actionText = (el) => [el && el.innerText, el && el.textContent, el && el.getAttribute && el.getAttribute('aria-label'), el && el.getAttribute && el.getAttribute('title'), el && el.value].filter(Boolean).join(' ').replace(/\\s+/g, ' ').trim();
  const buyActions = Array.from(document.querySelectorAll('button, [role="button"], a, input[type="submit"]'))
    .filter(el => visibleNow(el) && /(?:^|\\s)(?:купить(?:\\s+сейчас)?|buy(?:\\s+now)?|добавить\\s+в\\s+корзину|add\\s+to\\s+cart|оформить(?:\\s+заказ)?|place\\s+order)(?:\\s|$)/i.test(actionText(el)));
  // Also detect disabled buy buttons (e.g. "Нет в наличии") that identify the main
  // product's purchase area even though they don't match the "Купить" regex.
  const disabledBuyButtons = Array.from(document.querySelectorAll('button, [role="button"], a, input[type="submit"]'))
    .filter(el => visibleNow(el) && (el.disabled || el.getAttribute('aria-disabled') === 'true' ||
      /(?:нет\s+в\s+наличии|sold\s*out|out\s*of\s*stock|currently\s*unavailable)/i.test(actionText(el))));
  const domDistance = (a, b) => {
    if (!a || !b) return 9999;
    const ancestors = new Map(); let node = a, depth = 0;
    while (node && depth < 32) { ancestors.set(node, depth++); node = node.parentElement; }
    node = b; depth = 0;
    while (node && depth < 32) { if (ancestors.has(node)) return ancestors.get(node) + depth; depth++; node = node.parentElement; }
    return 9999;
  };
  const visualDistance = (a, b) => {
    try {
      const x = a.getBoundingClientRect(), y = b.getBoundingClientRect();
      const ax = x.left + x.width / 2, ay = x.top + x.height / 2;
      const bx = y.left + y.width / 2, by = y.top + y.height / 2;
      return Math.round(Math.hypot(ax - bx, ay - by) * 10) / 10;
    } catch (_) { return 999999; }
  };
  const els = Array.from(document.querySelectorAll('body *')).filter(el => {
    if (!visibleNow(el)) return false;
    const t = textOf(el);
    if (!isRubPrice(t)) return false;
    return !Array.from(el.children || []).some(ch => textOf(ch) === t && isRubPrice(textOf(ch)));
  });
  return els.map(p => {
    const cls = (p.className || '').toString().slice(0, 180);
    const id = p.id || '';
    const itemprop = p.getAttribute('itemprop') || '';
    const testid = p.getAttribute('data-testid') || '';
    const identity = (String(id) + ' ' + cls + ' ' + itemprop + ' ' + testid).toLowerCase();
    const style = (() => { try { return window.getComputedStyle(p); } catch (_) { return null; } })();
    const knownBuyBlock = p.closest('[class*="ProductBuyBlock"], [class*="BuyBlock"], [class*="buyBlock"], [class*="product-buy"], [data-testid*="buy" i], [data-testid*="product-buy" i]');
    const allBuyActions = [...buyActions, ...disabledBuyButtons];
    let actionBuyBlock = null, ancestor = p.parentElement;
    for (let depth = 0; ancestor && ancestor !== document.body && depth < 10; depth++, ancestor = ancestor.parentElement) {
      if (textOf(ancestor).length > 1600) break;
      if (allBuyActions.some(action => ancestor.contains(action))) { actionBuyBlock = ancestor; break; }
    }
    const buyBlock = knownBuyBlock || actionBuyBlock;
    const buyActionDisabled = buyBlock ? allBuyActions.some(action => buyBlock.contains(action) && (action.disabled || action.getAttribute('aria-disabled') === 'true')) : false;
    const priceAncestors = [];
    for (let node=p, depth=0; node && depth<5 && node!==document.body; node=node.parentElement,depth++) priceAncestors.push(node);
    const semanticAncestors = priceAncestors.map(node => {
      const cls = String(node.className && node.className.baseVal || node.className || '');
      const extra = node.getAttribute && (node.getAttribute('data-testid') || node.getAttribute('aria-label') || node.getAttribute('title')) || '';
      return String(node.id || '') + ' ' + cls + ' ' + extra;
    }).join(' ').toLowerCase();
    const oldPriceSemantic = /(?:^|[\\s_-])(?:old|was|previous|original|regular|before|full|strike|strikethrough|crossed|crossout)(?:[\\s_-]|$)|(?:old|was|previous|original|regular|before|strike|cross|through)[_-]?(?:product[_-]?)?price|price[_-]?(?:old|was|previous|original|regular|before|full)|pricebefore|priceold|priceoriginal/i.test(semanticAncestors);
    const decorationOnAncestor = priceAncestors.some((node, depth) => {
      // A broad price-list/discount wrapper can contain both current and old prices.
      // Only inherit line-through from the price node or its immediate wrapper.
      if (depth > 1) return false;
      try { const st = window.getComputedStyle(node); return String(st.textDecorationLine || st.textDecoration || '').toLowerCase().includes('line-through'); } catch (_) { return false; }
    });
    const struckAncestor = p.closest('del, s, strike, [class*="oldPrice" i], [class*="previousPrice" i], [class*="originalPrice" i], [class*="compareAt" i], [class*="wasPrice" i], [class*="line-through" i], [class*="strikethrough" i], [class*="crossed" i], [class*="price-before" i], [class*="price_before" i], [class*="price-old" i], [class*="price_old" i], [class*="price-original" i], [class*="price_original" i], [class*="price-regular" i], [class*="price_regular" i]');
    const struckThrough = Boolean(struckAncestor || oldPriceSemantic || decorationOnAncestor || (style && String(style.textDecorationLine || style.textDecoration || '').toLowerCase().includes('line-through')));
    const priceRole = struckThrough ? 'old' : /(?:current|actual|sale|discounted|final|selling|product[_-]?price[_-]?value|price[_-]?(?:current|sale|final))/i.test(semanticAncestors) ? 'current' : 'normal';
    const buyActionDistance = buyActions.length ? Math.min(...buyActions.map(action => domDistance(p, action))) : 9999;
    const buyActionVisualDistance = buyActions.length ? Math.min(...buyActions.map(action => visualDistance(p, action))) : 999999;
    const fontSizePx = style ? (parseFloat(style.fontSize) || 0) : 0;
    // Score the price node itself; a broad buy-block ancestor can contain stale or alternate prices.
    let selectorScore = Math.round(fontSizePx * 1.5);
    if (itemprop === 'price' || /(?:^|[\\s_-])id_product_price(?:$|[\\s_-])/i.test(identity)) selectorScore += 1200;
    if (/(?:current|actual|sale|final|main)[_-]?(?:product[_-]?)?price|(?:product[_-]?price)[_-]?(?:current|value|amount)|price[_-]?(?:current|value|amount)/i.test(identity)) selectorScore += 150;
    else if (/(?:^|[\\s_-])(?:product[_-]?)?price(?:$|[\\s_-])/i.test(identity)) selectorScore += 30;
    if (/price(?:variant|option|card|item|related|old|previous|original|compare|was)|(?:variant|option|related|old|previous|original|compare|was)price/i.test(identity)) selectorScore -= 500;
    if (buyBlock) selectorScore += 40;
    if (buyActionDistance < 9999) selectorScore += Math.max(0, 120 - buyActionDistance * 8);
    return {
      text: textOf(p), cls, id, itemprop, testid,
      visible: visibleNow(p), hiddenTree: hiddenTree(p),
      inBuyBlock: Boolean(buyBlock),
      buyBlockClass: buyBlock ? (buyBlock.className || '').toString().slice(0, 120) : '',
      buyActionText: actionBuyBlock ? (buyActions.find(action => actionBuyBlock.contains(action))?.innerText || buyActions.find(action => actionBuyBlock.contains(action))?.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 80) : '',
      buyActionDistance, visualDistance: buyActionVisualDistance, fontSizePx, selectorScore, struckThrough, priceRole, buyActionDisabled,
      tag: String(p.tagName || '').toLowerCase()
    };
  }).filter(p => !/Steam RUB|Steam KZT|Steam UAH|USD\\s*=/.test(p.text));
};

const detectTemplate = () => {
  if (document.querySelector('[class*="ProductBuyBlock"]')) return 'ggsel';
  if (!document.querySelector('[class*="id_product_price"]')) return 'unknown';
  if (Array.from(document.querySelectorAll('label')).some(l => /Требуется Вход|Случайный Email/i.test(l.innerText || ''))) return 'plati-A';
  if (Array.from(document.querySelectorAll('label')).some(l => /Subscription.*\\+|Subscription.*Месяц|Subscription.*Month/i.test(l.innerText || ''))) return 'plati-B';
  if (document.querySelectorAll('input[type="radio"]').length > 0) return 'plati-C';
  return 'plati-A';
};

const grabPageText = () => {
  const t = (document.body && document.body.innerText) || '';
  return t.replace(/[ \\t]+/g, ' ').replace(/\\n{3,}/g, '\\n\\n').trim().slice(0, 6000);
};

// Seller description is often collapsed behind a "Показать ещё" expander,
// so innerText misses it; textContent of description containers still has it.
const grabDescText = () => {
  const sels = ['[itemprop="description"]', '[class*="escription"]', '[id*="escription"]', '[class*="desc"]'];
  const parts = [];
  for (const sel of sels) {
    document.querySelectorAll(sel).forEach((el) => {
      const t = (el.textContent || '').replace(/\\s+/g, ' ').trim();
      if (t.length > 40 && parts.indexOf(t) === -1) parts.push(t);
    });
  }
  return parts.slice(0, 5).join('\\n---\\n').slice(0, 5000);
};

const collectVariantControls = () => {
  const controls = [];
  const skipped = [];
  const seen = new Map();
  const seenSkipped = new Set();
  const BUY_SELECTOR = '[class*="ProductBuyBlock"], [class*="BuyBlock"], [class*="buyBlock"], [class*="product-buy"], [data-testid*="buy" i], [data-testid*="product-buy" i]';
  const cleanText = value => String(value || '').replace(/\\s+/g, ' ').trim();
  const variantDisplayKey = value => cleanText(value).normalize('NFKC').replace(/^\\s*\\d{1,2}[.)]\\s*/, '').toLocaleLowerCase('ru').replace(/ё/g, 'е').replace(/[\\s_–—-]+/g, ' ').replace(/[^\\p{L}\\p{N} ]/gu, '').trim();
  const isVisible = el => {
    try {
      if (!el || !el.getClientRects().length) return false;
      for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
        if (node.hidden || node.hasAttribute('inert') || node.getAttribute('aria-hidden') === 'true') return false;
        const st = getComputedStyle(node);
        if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity || 1) <= 0.01) return false;
        if (node === document.documentElement) break;
      }
      return true;
    } catch (_) { return false; }
  };
  let inferredBuyBlock = document.querySelector(BUY_SELECTOR);
  if (!inferredBuyBlock) {
    const actions = Array.from(document.querySelectorAll('button,[role="button"],a[href],input[type="submit"]'))
      .filter(el => isVisible(el) && /купить(?:\\s+сейчас)?|buy(?:\\s+now)?|добавить\\s+в\\s+корзину|add\\s+to\\s+cart|оформить(?:\\s+заказ)?|place\\s+order/i.test(cleanText(el.innerText || el.textContent || el.getAttribute('aria-label') || el.title)));
    for (const action of actions) {
      let node = action.parentElement;
      for (let depth = 0; node && depth < 9 && node !== document.body; depth++, node = node.parentElement) {
        const text = cleanText(node.innerText || node.textContent);
        if (text.length > 1800) break;
        const count = node.querySelectorAll('button,a[href],select,input,[role="option"],[role="radio"],[data-value],[data-option]').length;
        if (count >= 2 && (count >= 3 || /₽|руб|RUB|USD|EUR|KZT|UAH|TRY|€|\\$/i.test(text))) { inferredBuyBlock = node; break; }
      }
      if (inferredBuyBlock) break;
    }
  }
  const SELLER_PROFILE_HREF = /\\/(?:users?|profile|sellers?|merchant|vendor|authors?|stores?|shops?)(?:\\/|$|[?#])|\\/catalog\\/seller(?:\\/|$)|[?&](?:user|seller|profile)(?:_id)?=/i;
  const SELLER_META_MARKER = /(?:seller[-_\\s]?(?:card|info|name|profile)?|merchant|vendor|author[-_\\s]?(?:card|name|profile)|profile[-_\\s]?(?:card|name)|user[-_\\s]?(?:card|name|profile)|продавец|продавца)/i;
  const isSellerMetadata = el => {
    if (!el) return false;
    const link = el.closest && el.closest('a[href]');
    if (link && SELLER_PROFILE_HREF.test(String(link.getAttribute('href') || ''))) return true;
    for (let node = el, depth = 0; node && depth < 5 && node !== document.body; node = node.parentElement, depth++) {
      const identity = [node.className && node.className.baseVal || node.className || '', node.id || '', node.getAttribute && node.getAttribute('data-testid') || '', node.getAttribute && node.getAttribute('aria-label') || '', node.getAttribute && node.getAttribute('title') || ''].join(' ');
      if (SELLER_META_MARKER.test(identity)) return true;
    }
    return false;
  };
  const isCompositeOptionText = value => {
    const text = cleanText(value);
    const descriptors = (text.match(/\\((?:Игра|DLC|Без основной игры)\\)/gi) || []).length;
    const editions = (text.match(/\\b(?:Standard|GOTY|Creations\\s+Bundle|Anniversary\\s+(?:Upgrade|Edition))\\b/gi) || []).length;
    return descriptors >= 2 || editions >= 3 || /(?:\\bFunPay\\b.*\\d{1,2}\\.\\d{1,2}\\.\\d{4}|\\bRUB\\s*[-–/]\\s*KZT\\s*[-–/]\\s*UAH)/i.test(text);
  };
  const FIELD_PROMPT = /^\\s*(регион|страна|издани[ея]|платформ[аы]?|вариант|region|country|edition|platform|variant)\\s*[*:：]?\\s*$/iu;
  // Keyword gate decides WHICH controls we click; rejected labels remain in "skipped"
  // for diagnostics, but seller metadata and composite wrappers never enter the control list.
  const KEY = /Max|Pro|Lite|Plus|Плюс|GO|Токен|Месяц|Год|month|year|Первая|Продление|Subscription|Случайный|Требуется|месяц|год|нов(?:ый|ая)\\s+(?:аккаунт|учетн)|предоставлю|свой\\s+аккаунт|account|global|worldwide|world\\s+wide|region|country|регион|страна|глобальн|весь\\s+мир|Worldwide|\\bROW\\b|\\bEMEA\\b|\\bAPAC\\b|\\bLATAM\\b|\\bCIS\\b|СНГ|Russia|Russian|\\bRU\\b|Россия|российск|Europe|European|\\bEU\\b|Европ|USA|U\\.?S\\.?A?\\.?|United\\s+States|США|Turkey|Turkiye|\\bTR\\b|Турци|Kazakhstan|\\bKZ\\b|Казахстан|Ukraine|\\bUA\\b|Украин|Belarus|Беларус|China|Китай|Philippin|Филипп|Azerbaijan|Азербайджан|Armenia|Армени|Georgia|Грузия|Kyrgyz|Кыргыз|Moldova|Молдова|Tajik|Таджик|Turkmen|Туркмен|Uzbek|Узбеки|United\\s+Kingdom|Great\\s+Britain|England|\\bUK\\b|Великобрит|Англия|Argentina|\\bAR\\b|Аргентин|Brazil|\\bBR\\b|Бразил|India|\\bIN\\b|Индия|Japan|\\bJP\\b|Япони|Korea|\\bKR\\b|Коре|Australia|\\bAU\\b|Австрал|Steam|Epic|GOG|Ubisoft|Xbox|PlayStation|Nintendo|\\bPC\\b|\\bPS[345]\\b|Base\\s+Game|Base\\s+Edition|Базовая\\s+игра|Основная\\s+игра|Базовая\\s+версия|Standard|Deluxe|Ultimate|Premium|Basic|Complete|Definitive|GOTY|Gold|Silver|Platinum|Collector|Remastered|Anniversary|Edition|Издание|Стандартн|Делюкс|Полное\\s+издание|Ultimate|Лицензия|Активац/i;
  const availabilityMeta = (el, text) => {
    const input = el && (el.matches && el.matches('input, option')
      ? el
      : el.querySelector && el.querySelector('input[type="radio"], input[type="checkbox"], option'));
    const disabled = Boolean(
      (el && el.disabled) || (input && input.disabled) ||
      (el && el.getAttribute && el.getAttribute('aria-disabled') === 'true') ||
      (input && input.getAttribute && input.getAttribute('aria-disabled') === 'true')
    );
    const unavailableText = isUnavailableText(text);
    return {
      disabled,
      ariaDisabled: Boolean(el && el.getAttribute && el.getAttribute('aria-disabled') === 'true'),
      available: !(disabled || unavailableText),
      unavailableReason: disabled ? 'disabled control' : (unavailableText ? 'unavailable text' : ''),
      selected: isSelectedElement(el, text),
    };
  };
  const hasExplicitVariantMetadata = el => {
    for (let node = el, depth = 0; node && depth < 4 && node !== document.body; node = node.parentElement, depth++) {
      if (node.matches && node.matches('[role="option"],[role="radio"],[data-value],[data-label],[data-option],[data-variant],input[type="radio"],input[type="checkbox"],select,option')) return true;
      const identity = [node.className && node.className.baseVal || node.className || '', node.id || '', node.getAttribute && node.getAttribute('data-testid') || ''].join(' ');
      if (/(?:variant|option|region|country|edition|selector|choice|switch|tab|вариант|регион|страна|издани|параметр|выбор)/i.test(identity)) return true;
    }
    return false;
  };
  const record = (kind, text, meta, el) => {
    const k = cleanText(text);
    if (!el || !isVisible(el) || !k || k.length > 250 || isCompositeOptionText(k)) return;
    const displayKey = variantDisplayKey(k);
    if (!displayKey) return;
    const normalizedText = k.toLocaleLowerCase('ru').replace(/ё/g, 'е').replace(/[^\\p{L}\\p{N}]+/gu, ' ');
    const textWords = new Set(normalizedText.split(/\\s+/).filter(Boolean));
    const matchesRequestedVariant = REQUESTED_VARIANT_WORDS.length > 0 && REQUESTED_VARIANT_WORDS.every(word => textWords.has(word));
    const looksLikeNumberedOption = /^\\s*\\d{1,2}[.)]\\s+\\S/.test(k);
    const inGgselBuyBlock = Boolean(el && ((el.closest && el.closest(BUY_SELECTOR)) || (inferredBuyBlock && inferredBuyBlock.contains(el))));
    const inSiteChrome = Boolean(el && el.closest && el.closest('nav,header,footer,[role="navigation"],[class*="navbar" i],[class*="site-menu" i],[class*="main-menu" i]'));
    if (isSellerMetadata(el)) return;
    if (inSiteChrome && !inGgselBuyBlock) return;
    const inVariantGroup = Boolean(meta && meta.inVariantGroup) || (kind === 'generic' && Boolean(optionGroupFor(el)));
    const genericAction = /^(?:buy(?:\\s+now)?|purchase|place\\s+order|купить|покупка|checkout|оформить|добавить\\s+в\\s+корзину|add\\s+to\\s+cart|перейти\\s+к\\s+оплате|оплатить)(?:\\s+.*)?$/i.test(k)
      || /^(?:выберите|выбрать|select|choose)(?:\\s+.*)?$/i.test(k)
      || /^(?:вход|регистрация|количество|quantity)$/i.test(k);
    const ggselBuyBoxOption = inGgselBuyBlock && hasExplicitVariantMetadata(el) && !genericAction && !/^(?:купить|buy|purchase|checkout|оформить|добавить\\s+в\\s+корзину|add\\s+to\\s+cart)(?:\\s|$)/i.test(k) && !/^\\s*\\d[\\d\\s.,]*\\s*(?:₽|руб(?:\\.|лей|ля)?|RUB)\\s*$/i.test(k);
    if (!KEY.test(k) && !matchesRequestedVariant && !looksLikeNumberedOption && !ggselBuyBoxOption && !(inVariantGroup && (KEY.test(k) || matchesRequestedVariant || looksLikeNumberedOption || hasExplicitVariantMetadata(el)))) {
      if (k.length >= 3 && !seenSkipped.has(k) && skipped.length < 80) { seenSkipped.add(k); skipped.push({ kind, text: k }); }
      return;
    }
    let domIndex = -1;
    if (kind === 'button') domIndex = Array.from(document.querySelectorAll('button')).indexOf(el);
    else if (kind === 'label') domIndex = Array.from(document.querySelectorAll('label')).indexOf(el);
    else if (kind === 'radio') domIndex = Array.from(document.querySelectorAll('input[type="radio"]')).indexOf(el);
    else if (kind === 'role-radio') domIndex = Array.from(document.querySelectorAll('[role="radio"]')).indexOf(el);
    else if (kind === 'link') domIndex = Array.from(document.querySelectorAll('a[href]')).indexOf(el);
    else if (kind === 'select-option') domIndex = Array.from(document.querySelectorAll('select option')).indexOf(el);
    const nearestLink = el.closest && el.closest('a[href]');
    const ctrl = { kind, text: k, domIndex, ...(meta || {}), elementHref: String(nearestLink && nearestLink.getAttribute('href') || ''), inVariantGroup, inPurchaseArea: inGgselBuyBlock, ...availabilityMeta(el, k) };
    const priority = (inGgselBuyBlock ? 1000 : 0) + (inVariantGroup ? 500 : 0) + (kind === 'generic' ? 20 : 0) + (el.matches && el.matches('button,[role="button"],[role="option"],[role="radio"],label,input,select') ? 5 : 0) + (ctrl.selected ? 2 : 0);
    const previous = seen.get(displayKey);
    if (previous && previous.priority >= priority) return;
    if (previous) controls[previous.index] = ctrl;
    else controls.push(ctrl);
    seen.set(displayKey, { index: previous ? previous.index : controls.length - 1, priority });
  };
  document.querySelectorAll('button').forEach(b => record('button', b.innerText || '', null, b));
  document.querySelectorAll('[role="button"]').forEach(el => record('role-button', el.innerText || el.textContent || '', null, el));
  document.querySelectorAll('[role="option"]').forEach(el => record('role-option', el.innerText || el.textContent || '', null, el));
  document.querySelectorAll('a[href]').forEach(el => record('link', el.innerText || el.textContent || el.getAttribute('aria-label') || el.title || '', null, el));
  document.querySelectorAll('[data-value],[data-label],[data-option],[data-variant]').forEach(el => {
    const attrs = ['data-label', 'data-variant', 'data-option', 'data-value'];
    const attr = attrs.find(name => el.hasAttribute(name) && String(el.getAttribute(name) || '').trim());
    const attrValue = attr ? String(el.getAttribute(attr) || '') : '';
    const text = el.innerText || el.textContent || attrValue;
    record('data-option', text, attr ? { dataAttribute: attr, dataValue: attrValue, elementTag: String(el.tagName || '').toLowerCase() } : null, el);
  });
  document.querySelectorAll('label').forEach(l => {
    const nested = l.querySelector('input[type="radio"], input[type="checkbox"]');
    const labelled = l.htmlFor && document.getElementById(l.htmlFor);
    const associated = nested || (labelled && /^(?:radio|checkbox)$/i.test(labelled.type || ''));
    const explicitlyInteractive = l.getAttribute('role') || l.tabIndex >= 0;
    if (associated || explicitlyInteractive) record('label', l.innerText || '', null, l);
  });
  document.querySelectorAll('input[type="radio"]').forEach(i => {
    const lab = i.closest('label');
    let text = '';
    if (lab) text = (lab.innerText || '').trim();
    else {
      const parent = i.closest('div, li, span');
      if (parent) text = (parent.innerText || '').trim().slice(0, 200);
    }
    if (!text) text = i.value || i.name || ('radio:' + i.id);
    record('radio', text, { inputId: i.id, inputName: i.name }, i);
  });
  document.querySelectorAll('[role="radio"]').forEach(el => record('role-radio', (el.innerText || '').trim(), null, el));
  document.querySelectorAll('select').forEach(s => {
    Array.from(s.options).forEach(o => record('select-option', (o.textContent || '').trim(), { value: o.value }, o));
  });

  // GGSEL product pages also render region/edition pills as plain div/span/li
  // nodes with delegated click handlers. They are not exposed as button/role/data
  // controls, so the original scan silently omitted choices such as Ukraine/Belarus.
  const GENERIC_VARIANT = /(Russia|Russian|Россия|Российск|Ukraine|Украин|\\bUA\\b|Беларус|Belarus|СНГ|\\bCIS\\b|Kazakhstan|Казахстан|Turkey|Turkiye|Турци|Argentina|Аргентин|Brazil|Бразил|India|Индия|China|Китай|USA|United States|США|Europe|Европ|Philippin|Филипп|Azerbaijan|Азербайджан|Armenia|Армени|Georgia|Грузия|Kyrgyz|Кыргыз|Moldova|Молдова|Tajik|Таджик|Turkmen|Туркмен|Uzbek|Узбеки|Global|Worldwide|Standard|Deluxe|Vault|Ultimate|Premium|Basic|Complete|Definitive|GOTY|Gold|Silver|Platinum|Collector|Remastered|Anniversary|Base Game|Base Edition|Стандарт|Делюкс|издани|регион|страна|вариант|версия)/i;
  const OPTION_CLASS = /(variant|option|region|country|edition|parameter|selector|choice|switch|tab|вариант|регион|страна|издани|параметр|выбор)/i;
  const isVariantLabel = value => GENERIC_VARIANT.test(cleanText(value)) && cleanText(value).length >= 2 && cleanText(value).length <= 220 && !/^(?:выберите|select|choose|купить|описание|характеристики)(?:\\s|$)/i.test(cleanText(value));
  const optionGroupFor = el => {
    for (let parent=el && el.parentElement, depth=0; parent && depth<7 && parent!==document.body; parent=parent.parentElement,depth++) {
      const text = cleanText(parent.innerText || parent.textContent || '');
      if (!text || text.length > 2300) break;
      const descendants = Array.from(parent.querySelectorAll('div,span,li,p,button,a[href],[role="button"],[role="option"],[role="radio"],label,[data-value],[data-option],[data-variant]'));
      const labels = new Set();
      for (const candidate of descendants) {
        if (!isVisible(candidate)) continue;
        const label = cleanText(candidate.innerText || candidate.textContent || '');
        if (!isVariantLabel(label)) continue;
        if (Array.from(candidate.children || []).some(child => cleanText(child.innerText || child.textContent || '') === label)) continue;
        labels.add(label.toLocaleLowerCase('ru'));
      }
      const prompt = /(?:выберите|выбрать|select|choose)\\s*.{0,36}(?:регион|стран|издани|вариант|region|country|edition|variant)/i.test(text);
      const cls = String(parent.className && parent.className.baseVal || parent.className || '') + ' ' + String(parent.id || '');
      if (labels.size >= 3 && (prompt || OPTION_CLASS.test(cls) || labels.size >= 4)) return parent;
    }
    return null;
  };
  const selectorEvidence = el => {
    for (let node=el, depth=0; node && depth<4 && node!==document.body; node=node.parentElement,depth++) {
      const cls = String(node.className && node.className.baseVal || node.className || '');
      if (node.hasAttribute('onclick') || node.hasAttribute('tabindex') || node.getAttribute('role') || node.hasAttribute('aria-pressed') || node.hasAttribute('aria-selected') || node.hasAttribute('data-value') || node.hasAttribute('data-option') || node.hasAttribute('data-variant')) return true;
      if (OPTION_CLASS.test(cls) || OPTION_CLASS.test(String(node.id || ''))) return true;
      try { if (getComputedStyle(node).cursor === 'pointer') return true; } catch (_) {}
    }
    return Boolean(optionGroupFor(el));
  };
  const sameText = (el, expected) => cleanText(el && (el.innerText || el.textContent || '')) === expected;
  const genericNodes = Array.from(document.querySelectorAll('div,span,li,p'));
  for (const node of genericNodes) {
    if (!isVisible(node)) continue;
    const label = cleanText(node.innerText || node.textContent || '');
    if (label.length < 2 || label.length > 220 || isCompositeOptionText(label) || FIELD_PROMPT.test(label) || isSellerMetadata(node) || !GENERIC_VARIANT.test(label) || /^(?:выберите|select|choose|купить|описание|характеристики)(?:\s|$)/i.test(label)) continue;
    // Avoid duplicate parent/child records: keep the smallest element that holds
    // the whole caption, while the eventual click bubbles to its interactive wrapper.
    if (Array.from(node.children || []).some(child => sameText(child, label))) continue;
    let target = node;
    for (let parent=node.parentElement, depth=0; parent && depth<3 && parent!==document.body; parent=parent.parentElement,depth++) {
      if (!sameText(parent, label)) break;
      const cls = String(parent.className && parent.className.baseVal || parent.className || '');
      let clickable = parent.hasAttribute('onclick') || parent.hasAttribute('tabindex') || !!parent.getAttribute('role') || OPTION_CLASS.test(cls);
      try { clickable = clickable || getComputedStyle(parent).cursor === 'pointer'; } catch (_) {}
      if (clickable) target = parent;
    }
    const variantGroup = optionGroupFor(target);
    if (!selectorEvidence(target) && !variantGroup) continue;
    const targetText = cleanText(target.innerText || target.textContent || label);
    if (targetText !== label) continue;
    record('generic', label, {
      elementTag: String(target.tagName || 'div').toLowerCase(),
      elementClass: String(target.className && target.className.baseVal || target.className || '').trim(),
      elementId: String(target.id || ''),
      elementRole: String(target.getAttribute && target.getAttribute('role') || ''),
      inVariantGroup: Boolean(variantGroup),
    }, target);
  }
  const collectPromptScopedControls = () => {
    // IMPORTANT: use Unicode letter properties. \\w* does not match Cyrillic
    // endings like "Выберите", so it silently skipped edition headings.
    const PROMPT = /(?:выбер\\p{L}*|выбира\\p{L}*|выбрать|select|choose)\\s*.{0,70}?(регион|стран|издани|вариант|верс|платформ|region|country|edition|variant|version|platform)/iu;
    const isPromptText = value => PROMPT.test(String(value || '')) || FIELD_PROMPT.test(String(value || ''));
    const REGION = /(росси|russia|russian|\\bru\\b|украин|ukraine|\\bua\\b|беларус|belarus|снг|\\bcis\\b|казахстан|kazakhstan|турци|turkey|turkiye|аргентин|argentina|бразил|brazil|индия|india|китай|china|сша|\\busa\\b|united states|европ|europe|филиппин|philippin|таиланд|thailand|thai|азербайджан|azerbaijan|армени|armenia|грузия|georgia|кыргыз|kyrgyz|молдова|moldova|таджик|tajik|туркмен|turkmen|узбеки|uzbek|global|worldwide|latin america|asia|middle east|japan|япони|korea|коре[яи]|любой\\s+(?:другой\\s+)?регион|другой\\s+регион|any\\s+other\\s+region|other\\s+region)/i;
    const EDITION = /(standard|deluxe|vault|ultimate|premium|basic|complete|definitive|goty|gold|silver|platinum|collector|remaster(?:ed)?|anniversary|base\\s*(?:game|edition)?|edition|издани|стандарт|делюкс|полное|базов|обычн|расширенн|коллекцион|classic|комплект|набор|season\\s*pass|bundle|pack|supporter)/i;
    const PLATFORM = /(steam|epic|gog|ubisoft|xbox|playstation|nintendo|\\bpc\\b|\\bps[345]\\b|battle\\.net|ea\\s*app|origin)/i;
    const NOISE = /(legitmarket|все сделки на ggsel|деньги резервируются|верн[её]м оплату|пополнени[ея]|автопополнени|оффлайн аккаунты|аренда аккаунтов|ссылка.{0,40}(?:профил|инвайт|приглаш)|(?:профил|инвайт|приглаш).{0,40}ссылк|profile.{0,40}(?:link|invite)|(?:profile|invite).{0,40}link|steam\\s*(?:rub|kzt|uah)\\s*=|rub\\s*-\\s*kzt\\s*-\\s*uah|steam.{0,50}\\d[\\d\\s.,]*\\s+продаж|all deals on ggsel)/i;
    const OPTION_PROMPT = /(?:выбер\\p{L}*|выбира\\p{L}*|выбрать|select|choose)\\s*.{0,55}(?:регион|стран|издани|вариант|верси|платформ|region|country|edition|variant|version|platform)/iu;
    const GENERIC_LABEL = /^(?:buy(?:\\s+now)?|purchase|place\\s+order|купить(?:\\s+сейчас)?|оформить(?:\\s+заказ)?|в\\s+корзину|добавить\\s+в\\s+корзину|добавить\\s+в\\s+избранное|в\\s+избранное|подробнее|показать\\s+ещ[её]|читать\\s+далее|свернуть|вход|регистрация|оплата|отзывы|описание|характеристики|доставка|выберите(?:\\s+(?:вариант|регион|издание|страну))?|выберете(?:\\s+(?:вариант|регион|издание|страну))?|выбрать|select(?:\\s+(?:option|variant|region|edition))?|choose(?:\\s+(?:option|variant|region|edition))?|option|количество|quantity|увеличить|уменьшить|сравнить)$/i;
    const normKey = variantDisplayKey;
    const typeFor = text => {
      const source = String(text || '');
      const match = source.match(PROMPT), field = source.match(FIELD_PROMPT);
      const word = String(match && match[1] || field && field[1] || '').toLowerCase();
      if (/регион|стран|region|country/.test(word)) return 'region';
      if (/издани|edition/.test(word)) return 'edition';
      if (/платформ|platform/.test(word)) return 'platform';
      return 'variant';
    };
    const interactiveOwn = el => Boolean(el && (el.matches && el.matches('button,a[href],select,option,input,[role="button"],[role="option"],[role="radio"],label,[aria-pressed],[aria-checked],[aria-selected],[data-value],[data-label],[data-option],[data-variant]') || el.hasAttribute('onclick') || el.hasAttribute('tabindex') || el.getAttribute('role') || el.hasAttribute('data-value') || el.hasAttribute('data-option') || el.hasAttribute('data-variant')));
    const interactiveEvidence = el => {
      for (let node = el, depth = 0; node && depth < 4 && node !== document.body; node = node.parentElement, depth++) {
        if (interactiveOwn(node)) return true;
        try { if (getComputedStyle(node).cursor === 'pointer') return true; } catch (_) {}
        const cls = String(node.className && node.className.baseVal || node.className || '');
        if (OPTION_CLASS.test(cls)) return true;
      }
      return false;
    };
    const hasExplicitOptionMetadata = el => {
      for (let node = el, depth = 0; node && depth < 4 && node !== document.body; node = node.parentElement, depth++) {
        if (node.matches && node.matches('[role="option"],[role="radio"],[data-value],[data-label],[data-option],[data-variant],input[type="radio"],input[type="checkbox"],select,option')) return true;
        const identity = [node.className && node.className.baseVal || node.className || '', node.id || '', node.getAttribute && node.getAttribute('data-testid') || ''].join(' ');
        if (OPTION_CLASS.test(identity)) return true;
      }
      return false;
    };
    const typeMatches = (label, type, el) => {
      const text = cleanText(label);
      if (text.length < 2 || text.length > 190 || isPromptText(text) || NOISE.test(text) || OPTION_PROMPT.test(text) || GENERIC_LABEL.test(text) || isCompositeOptionText(text) || isSellerMetadata(el)) return false;
      if (/\\d[\\d\\s.,]*\\s*(?:₽|руб(?:\\.|лей|ля)?|RUB|USD|EUR|KZT|UAH|TRY|€|\\$)|\\d[\\d\\s.,]*\\s+продаж/i.test(text)) return false;
      const hasRegion = REGION.test(text), hasPlatform = PLATFORM.test(text), hasEdition = EDITION.test(text);
      // GGSEL often puts edition+region into ONE single-choice group under a
      // "Выберите регион" prompt ("Forza Horizon 5 Deluxe Россия"). Rejecting
      // chips with an edition word makes only the base edition selectable, so
      // a requested Deluxe silently falls back to the Standard price.
      if (type === 'region') return hasRegion && !hasPlatform;
      if (type === 'edition') {
        if (hasRegion || hasPlatform) return false;
        // A bare anchor is usually seller/navigation metadata, not an edition control.
        if (el && el.matches && el.matches('a[href]') && !hasEdition && !hasExplicitOptionMetadata(el)) return false;
        // Edition names can be plain captions inside a real control group.
        return hasEdition || (hasExplicitOptionMetadata(el) && interactiveEvidence(el)) || (!(el && el.matches && el.matches('a[href]')) && interactiveEvidence(el));
      }
      if (type === 'platform') {
        if (hasRegion || hasEdition) return false;
        return hasPlatform || interactiveEvidence(el);
      }
      return hasRegion || hasEdition || hasPlatform || interactiveEvidence(el);
    };
    const nestedOptions = (el, type) => {
      const labels = new Set();
      for (const child of el.querySelectorAll('button,a[href],select,option,input,[role="button"],[role="option"],[role="radio"],label,[data-value],[data-label],[data-option],[data-variant],div,span,li,p')) {
        if (!isVisible(child)) continue;
        const text = cleanText(child.innerText || child.textContent || '');
        if (!typeMatches(text, type, child)) continue;
        if (Array.from(child.children || []).some(grand => cleanText(grand.innerText || grand.textContent || '') === text)) continue;
        labels.add(normKey(text));
        if (labels.size >= 2) return true;
      }
      return false;
    };
    const prompts = Array.from(document.querySelectorAll('label,legend,span,div,p,strong,b,h1,h2,h3')).filter(el => {
      if (!isVisible(el) || isSellerMetadata(el)) return false;
      const text = cleanText(el.innerText || el.textContent || '');
      if (text.length < 3 || text.length > 160 || !isPromptText(text) || NOISE.test(text) || isCompositeOptionText(text)) return false;
      return !Array.from(el.children || []).some(child => {
        const childText = cleanText(child.innerText || child.textContent || '');
        return childText.length >= 3 && childText.length < text.length && isPromptText(childText);
      });
    });
    const groupsByType = new Map();
    for (const prompt of prompts) {
      const promptText = cleanText(prompt.innerText || prompt.textContent || '');
      const type = typeFor(promptText);
      let group = null, singleFallback = null;
      for (let root = prompt.parentElement, depth = 0; root && depth < 8 && root !== document.body; root = root.parentElement, depth++) {
        const rootText = cleanText(root.innerText || root.textContent || '');
        if (!rootText || rootText.length > 2400) break;
        // Never let a group climb into the adjacent "Choose region" or "Choose edition"
        // block. This is what keeps a one-choice edition like EA SPORTS FC 26 separate.
        if (depth > 0 && prompts.some(other => {
          if (other === prompt || !root.contains(other) || prompt.contains(other) || other.contains(prompt)) return false;
          const otherText = cleanText(other.innerText || other.textContent || '');
          return otherText !== promptText && isPromptText(otherText);
        })) break;
        const items = new Map();
        const selector = 'button,a[href],select,option,input,[role="button"],[role="option"],[role="radio"],label,[data-value],[data-label],[data-option],[data-variant],[aria-pressed],[aria-checked],[aria-selected],div,span,li,p';
        for (const el of root.querySelectorAll(selector)) {
          if (!isVisible(el) || isSellerMetadata(el) || el === prompt || el.closest('nav,header,footer,[role="navigation"]')) continue;
          const text = cleanText(el.innerText || el.textContent || '');
          if (!typeMatches(text, type, el)) continue;
          if (Array.from(el.children || []).some(child => cleanText(child.innerText || child.textContent || '') === text)) continue;
          if (nestedOptions(el, type)) continue;
          const link = el.closest('a[href]');
          if (link && /\\/catalog\\/product\\//i.test(String(link.getAttribute('href') || '')) && !el.matches('[data-value],[data-option],[data-variant],[role="option"],[role="radio"]')) continue;
          const key = normKey(text);
          if (!key) continue;
          let target = el;
          for (let parent = el.parentElement, levels = 0; parent && levels < 3 && parent !== document.body; parent = parent.parentElement, levels++) {
            if (cleanText(parent.innerText || parent.textContent || '') !== text) break;
            const cls = String(parent.className && parent.className.baseVal || parent.className || '');
            let clickable = interactiveOwn(parent);
            try { clickable = clickable || getComputedStyle(parent).cursor === 'pointer'; } catch (_) {}
            if (clickable) target = parent;
          }
          const meta = availabilityMeta(target, text);
          const candidate = {
            kind: 'generic', text, domIndex: -1, type,
            elementTag: String(target.tagName || 'div').toLowerCase(),
            elementClass: String(target.className && target.className.baseVal || target.className || '').trim(),
            elementId: String(target.id || ''), elementRole: String(target.getAttribute && target.getAttribute('role') || ''),
            inVariantGroup: true, inPromptScopedGroup: true, inPurchaseArea: isInPurchaseArea(target), ...meta
          };
          const previous = items.get(key);
          if (!previous || (candidate.selected && !previous.selected) || (candidate.inPurchaseArea && !previous.inPurchaseArea)) items.set(key, candidate);
        }
        if (items.size >= 2) { group = { type, items: Array.from(items.values()), rootTextLength: rootText.length }; break; }
        if (items.size === 1 && !singleFallback) singleFallback = { type, items: Array.from(items.values()), rootTextLength: rootText.length };
      }
      if (!group) group = singleFallback;
      if (!group || !group.items.length) continue;
      const byLabel = groupsByType.get(type) || new Map();
      for (const item of group.items) {
        const key = normKey(item.text), previous = byLabel.get(key);
        if (key && (!previous || (item.selected && !previous.selected) || (item.inPurchaseArea && !previous.inPurchaseArea))) byLabel.set(key, item);
      }
      groupsByType.set(type, byLabel);
    }
    const unique = new Map();
    for (const [type, group] of groupsByType) for (const [labelKey, item] of group) {
      const key = type + '::' + labelKey;
      if (key && !unique.has(key)) unique.set(key, item);
    }
    return Array.from(unique.values());
  };
  const scopedControls = collectPromptScopedControls();
  return { controls, skipped, scopedControls };
};

const resolveControl = (ctrl) => {
  if (!ctrl) return null;
  if (ctrl.kind === 'data-option' && ctrl.dataAttribute && ctrl.dataValue != null) {
    const matches = Array.from(document.querySelectorAll('[data-value],[data-label],[data-option],[data-variant]'))
      .filter(el => controlVisible(el) && el.getAttribute(ctrl.dataAttribute) === String(ctrl.dataValue))
      .filter(el => String(el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim() === String(ctrl.text || '').replace(/\\s+/g, ' ').trim());
    let pick = matches;
    if (matches.length > 1) {
      const purchase = matches.filter(isInPurchaseArea);
      if (purchase.length) pick = purchase;
    }
    return pick.length === 1 ? pick[0] : null;
  }
  let el = findElement(ctrl.kind, ctrl.text, true, ctrl);
  if (!el) {
    const prefix = (ctrl.text || '').split('\\n')[0].slice(0, 25);
    if (prefix.length > 5) el = findElement(ctrl.kind, prefix, false, ctrl);
  }
  // Fall back to DOM index when text-based lookup fails after re-render.
  if (!el && Number.isInteger(ctrl.domIndex) && ctrl.domIndex >= 0) {
    el = findElementByIndex(ctrl.kind, ctrl.domIndex);
  }
  // Never fall back to a stale DOM index after a re-render.
  if (!el && ctrl.kind === 'radio' && ctrl.inputId) {
    const input = document.getElementById(ctrl.inputId);
    if (input && controlVisible(input)) el = input.closest('label') || input;
  }
  return el;
};

const clickControl = (ctrl) => {
  const el = resolveControl(ctrl);
  if (!el) return false;
  fireClick(el);
  return true;
};

const controlIsSelected = (ctrl) => {
  const el = resolveControl(ctrl);
  return isSelectedElement(el, (el && (el.innerText || el.textContent)) || ctrl.text || '');
};
`;

// ---- Each page.evaluate call wraps PAGE_FN + a small body that returns ---

async function detectTemplate(page) {
  return await page.evaluate(new Function(PAGE_FN + '\nreturn detectTemplate();'));
}
async function collectVariantControls(page, variantHint = '') {
  const evaluate = new Function('variantHint', PAGE_FN + `
    REQUESTED_VARIANT_HINT = String(variantHint || '');
    REQUESTED_VARIANT_WORDS = REQUESTED_VARIANT_HINT.toLocaleLowerCase('ru').replace(/ё/g, 'е').split(/[^\\p{L}\\p{N}]+/u).filter(Boolean);
    return collectVariantControls();
  `);
  return await page.evaluate(evaluate, variantHint);
}
async function grabPageText(page) {
  try {
    return await page.evaluate(new Function(PAGE_FN + '\nreturn grabPageText();'));
  } catch (e) { return ''; }
}
async function grabDescText(page) {
  try {
    return await page.evaluate(new Function(PAGE_FN + '\nreturn grabDescText();'));
  } catch (e) { return ''; }
}
async function grabIdentityHeadings(page) {
  try {
    return await page.evaluate(() => Array.from(document.querySelectorAll('h1,[itemprop="name"],meta[property="og:title"]'))
      .map(el => String(el.tagName === 'META' ? el.content : (el.innerText || el.textContent || '')).replace(/\s+/g, ' ').trim())
      .filter(Boolean).filter((value, index, all) => all.indexOf(value) === index).slice(0, 6));
  } catch (_) { return []; }
}
async function snapshotPrices(page) {
  try {
    return await page.evaluate(new Function(PAGE_FN + '\nreturn snapshotPrices();'));
  } catch (e) { return []; }
}

const priceFingerprint = (prices) => {
  const all = prices || [];
  const eligible = all.filter(p => p.struckThrough !== true && p.visible !== false);
  const buyBox = eligible.filter(p => p.inBuyBlock === true);
  const primary = eligible.filter(p => {
    const cls = String(p.cls || '').toLowerCase();
    return cls.includes('id_product_price') || (cls.includes('buyblock') && cls.includes('amount'));
  });
  // The selected GGSEL edition changes the buy box, not all prices shown in
  // recommendations/related lots. Fingerprint that active area first.
  const basis = buyBox.length ? buyBox : primary.length > 0 ? primary : all;
  return JSON.stringify(basis.map(p => [p.text || '', p.cls || '', p.id || '', Boolean(p.inBuyBlock), Boolean(p.struckThrough)]));
};

async function waitForSettledPrices(page, beforePrices, selectedBefore, controlToVerify = null) {
  const started = Date.now();
  const before = priceFingerprint(beforePrices);
  let previous = '';
  let stableSamples = 0;
  let latest = beforePrices;
  let changed = false;
  while (Date.now() - started < PRICE_SETTLE_TIMEOUT_MS) {
    await sleep(200);
    latest = await snapshotPrices(page);
    const current = priceFingerprint(latest);
    changed = changed || current !== before;
    stableSamples = current === previous ? stableSamples + 1 : 0;
    previous = current;
    let selectedNow = false;
    if (controlToVerify) {
      try { selectedNow = await controlIsSelected(page, controlToVerify); } catch (_) {}
    }
    const elapsedMs = Date.now() - started;
    // GGSEL updates the selected chip before the active buy-box price finishes
    // rendering. Require a longer quiet window for requested variants so we do
    // not save the previous edition's price under the newly selected label.
    if (controlToVerify) {
      // A changed buy-box price is direct evidence that the reactive update landed.
      // If the amount stays equal, wait longer before accepting it as a legitimate
      // equal-price variant; selected-state often updates ahead of the price request.
      if (stableSamples >= 3 && elapsedMs >= 1400 && changed) {
        return { prices: latest, changed, stable: true, elapsedMs };
      }
      if (stableSamples >= 4 && elapsedMs >= 2200 && selectedNow) {
        return { prices: latest, changed, stable: true, elapsedMs };
      }
    } else if (stableSamples >= 2 && (changed || selectedBefore || selectedNow)) {
      return { prices: latest, changed, stable: true, elapsedMs };
    }
  }
  // An unchanged snapshot can still be stable.  It becomes verified only if
  // the control is independently observed as selected after the click.
  return { prices: latest, changed, stable: stableSamples >= 2, elapsedMs: Date.now() - started };
}
async function clickControl(page, ctrl) {
  const selectors = {
    button: 'button', label: 'label', radio: 'input[type="radio"]',
    'role-radio': '[role="radio"]', 'role-button': '[role="button"]',
    'role-option': '[role="option"]', link: 'a[href]', 'select-option': 'select option',
  };
  const selector = selectors[ctrl.kind];
  let target = null;
  if (ctrl.kind === 'button' && ctrl.text) {
    const byText = page.getByRole('button', { name: ctrl.text, exact: true });
    if (await byText.count() === 1) target = byText;
  }
  // React/MUI can re-render controls after each selection. Match only visible,
  // exact labels and reject ambiguous matches instead of clicking the first one.
  if (!target && ctrl.text && ['label', 'role-radio', 'radio', 'role-button', 'role-option', 'link'].includes(ctrl.kind)) {
    const preferred = ctrl.kind === 'role-radio' ? '[role="radio"]' : ctrl.kind === 'role-button' ? '[role="button"]' : ctrl.kind === 'link' ? 'a[href]' : ctrl.kind === 'role-option' ? '[role="option"]' : 'label';
    const index = await page.locator(preferred).evaluateAll((els, wanted) => {
      const visible = el => {
        if (!el.getClientRects().length) return false;
        for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
          if (n.hidden || n.hasAttribute('inert') || n.getAttribute('aria-hidden') === 'true') return false;
          const st = getComputedStyle(n);
          if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity || 1) <= .01) return false;
          if (n === document.documentElement) break;
        }
        return true;
      };
      const text = el => String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      const matches = els.map((el, i) => ({el, i})).filter(({el}) => visible(el) && text(el) === wanted.replace(/\s+/g, ' ').trim());
      if (matches.length === 1) return matches[0].i;
      const buy = matches.filter(({el}) => el.closest('[class*="ProductBuyBlock"], [class*="BuyBlock"], [class*="buyBlock"], [class*="product-buy"], [data-testid*="buy" i], [data-testid*="product-buy" i]'));
      return buy.length === 1 ? buy[0].i : -1;
    }, ctrl.text).catch(() => -1);
    if (index >= 0) target = page.locator(preferred).nth(index);
  }
  // No numeric DOM-index fallback: re-rendering can move the requested option to another region/edition.
  if (target && await target.count()) {
    if (ctrl.kind === 'select-option') {
      await target.evaluate((option) => {
        option.selected = true;
        option.parentElement.dispatchEvent(new Event('input', { bubbles: true }));
        option.parentElement.dispatchEvent(new Event('change', { bubbles: true }));
      });
    } else await target.click({ timeout: CLICK_TIMEOUT_MS });
    return true;
  }
  return await page.evaluate(new Function(PAGE_FN + `return clickControl(${JSON.stringify(ctrl)});`));
}
async function controlIsSelected(page, ctrl) {
  try {
    return await page.evaluate(new Function(PAGE_FN + `
      return controlIsSelected(${JSON.stringify(ctrl)});
    `));
  } catch (e) { return false; }
}

async function withTimeout(p, ms, label) {
  let to;
  const t = new Promise((_, rej) => { to = setTimeout(() => rej(new Error(label + ' timeout')), ms); });
  try { return await Promise.race([p, t]); } finally { clearTimeout(to); }
}

function normalizeRequestedVariant(value) {
  let text = String(value || '').toLocaleLowerCase('ru').replace(/ё/g, 'е');
  // Replace full geographic names separately from two-letter codes. Do not
  // match "us" inside words like "Plus" or "Deluxe Plus".
  const synonyms = [
    [/united states of america|united states|u\.s\.a\.|сша|соединенные штаты/giu, ' usa '],
    [/\b(?:usa|us)\b/giu, ' usa '],
    [/european union|european|europe|европейский союз|европейский|европейская|европейское|европа/giu, ' eu '],
    [/\b(?:eu)\b/giu, ' eu '],
    [/russian federation|российская федерация|российский|российская|российское|россия/giu, ' ru '],
    [/\b(?:ru)\b/giu, ' ru '],
    [/turkiye|turkey|турция|турецкий|турецкая/giu, ' tr '],
    [/\b(?:tr)\b/giu, ' tr '],
    [/kazakhstan|казахстан|казахстанский/giu, ' kz '],
    [/\b(?:kz)\b/giu, ' kz '],
    [/ukraine|украина|украинский|украинская/giu, ' ua '],
    [/\b(?:ua)\b/giu, ' ua '],
    [/united kingdom|great britain|england|britain|великобритания|англия/giu, ' uk '],
    [/\b(?:uk)\b/giu, ' uk '],
    [/commonwealth of independent states|снг/giu, ' cis '],
    [/\b(?:cis)\b/giu, ' cis '],
    [/worldwide|world wide|global version|global|весь мир|глобальный|глобальная|глобальное|все регионы/giu, ' global '],
    [/latin america|латинская америка/giu, ' latam '],
    [/\b(?:latam)\b/giu, ' latam '],
    [/asia pacific|азиатский регион|азиатский|азиатская|азия/giu, ' asia '],
    [/\b(?:apac|asia)\b/giu, ' asia '],
    [/base\s+game|base\s+edition|базовая игра|основная игра|базовая версия/giu, ' base game '],
    [/standard edition|standard|standart|стандартное издание|стандартная версия|стандартный|стандартная|стандартное|стандарт/giu, ' standard '],
    [/deluxe edition|deluxe|делюкс издание|делюкс/giu, ' deluxe '],
    [/ultimate edition|ultimate|ультимативное издание|ультимативный/giu, ' ultimate '],
  ];
  for (const [pattern, replacement] of synonyms) text = text.replace(pattern, replacement);
  const tokens = text.replace(/[^\p{L}\p{N}]+/gu, ' ').trim().split(/\s+/).filter(Boolean);
  // Keep repeated tokens: deduplicating them made "ASSETTO CORSA ASSETTO
  // CORSA ULTIMATE" normalize to the distinct edition "ASSETTO CORSA ULTIMATE".
  return tokens.join(' ');
}
function splitRequestedVariant(value) {
  // A literal plus inside a label such as "СНГ+Беларусь" is part of the
  // region name. Only split plus signs used as separators with surrounding spaces.
  return String(value || '').split(/\s+\+\s+|[;|]/).map(s => s.trim()).filter(Boolean);
}
const VARIANT_CONTROL_NOISE = /(?:возможна отправка на следующие регионы|доступные регионы|возможные регионы|выбер(?:ите|ете)\s+(?:регион|издание|вариант)|выбор\s+издани[яе]|все сделки на ggsel|деньги резервируются|верн[её]м оплату|легитмаркет|legitmarket|rpg-market|пополнени[ея]|автопополнени|steam\s*(?:rub|kzt|uah)\s*=|\d[\d\s.,]*\s+продаж(?:а|и)?)/i;
function isPlausibleVariantControl(control) {
  const text = String(control && control.text || '').replace(/\s+/g, ' ').trim();
  const meta = [control && control.elementClass, control && control.elementId, control && control.elementHref, control && control.dataTestId].join(' ');
  // GGSEL may render the selector caption and its current value as one text
  // node (for example, "Издание* Call of Duty ..."). It is not an option.
  if (/^(?:регион|страна|издани[ея]|платформ[аы]?|вариант|версия|region|country|edition|platform|variant|version)\s*[*:：]\s*\S/iu.test(text)) return false;
  const descriptors = (text.match(/\((?:Игра|DLC|Без основной игры)\)/gi) || []).length;
  const editions = (text.match(/\b(?:Standard|GOTY|Creations\s+Bundle|Anniversary\s+(?:Upgrade|Edition))\b/gi) || []).length;
  if (descriptors >= 2 || editions >= 3 || /(?:\bFunPay\b.*\d{1,2}\.\d{1,2}\.\d{4}|\bRUB\s*[-–/]\s*KZT\s*[-–/]\s*UAH)/i.test(text)) return false;
  if (/(?:seller[-_\s]?(?:card|info|name|profile)?|merchant|vendor|author[-_\s]?(?:card|name|profile)|profile[-_\s]?(?:card|name)|user[-_\s]?(?:card|name|profile)|продавец|продавца)/i.test(meta) || /\/(?:users?|profile|sellers?|merchant|vendor)(?:\/|$|[?#])|[?&](?:user|seller|profile)(?:_id)?=/i.test(String(control && control.elementHref || ''))) return false;
  if (!text || text.length > 220 || VARIANT_CONTROL_NOISE.test(text)) return false;
  if (/^(?:аккаунты|оффлайн аккаунты|аренда аккаунтов|получите|логин steam|купить за|keybd|описание|характеристики)$/i.test(text)) return false;
  if (/(?:^|\s)[•·]\s*[-–—]\s*(?:росси|беларус|казахстан|укр|снг|турци|аргентин)/i.test(text) && text.length > 100) return false;
  if ((text.match(/(?:^|\s)[–—-]\s+/g) || []).length >= 3) return false;
  return true;
}
// A combined chip like "Стандарт Россия" contains BOTH an edition and a region.
// controlDimension() checks the region first and calls it 'region', which makes
// the auto-repair below think no edition was requested and click the currently
// selected (often Deluxe) chip instead. Check for an explicit edition word
// separately so an explicit "Стандарт" is always honoured.
const EDITION_MENTION_RE = /(?:standard|deluxe|ultimate|premium|basic|complete|definitive|goty|gold|silver|platinum|collector|remaster|anniversary|edition|издани|стандарт|делюкс|полное|базов|supporter)/i;
function mentionsEdition(value) {
  return EDITION_MENTION_RE.test(String(value || ''));
}
function controlDimension(control) {
  const declared = String(control && control.type || '').toLowerCase();
  if (['edition', 'region', 'platform'].includes(declared)) return declared;
  const text = String(control && control.text || '');
  if (/(?:росси|russia|\bru\b|казахстан|kazakhstan|\bkz\b|украин|\bua\b|беларус|снг|\bcis\b|турци|turkey|аргентин|argentina|индия|india|китай|china|таиланд|thailand|бразил|brazil|филиппин|philippin|сша|\busa\b|\beu\b|европ|europe|global|любой регион|other region)/i.test(text)) return 'region';
  if (/(?:standard|deluxe|ultimate|premium|basic|complete|definitive|goty|gold|silver|platinum|collector|remaster|anniversary|edition|издани|стандарт|делюкс|полное|базов|supporter)/i.test(text)) return 'edition';
  if (/(?:steam|epic|gog|ubisoft|xbox|playstation|nintendo|\bpc\b|\bps[345]\b|battle\.net)/i.test(text)) return 'platform';
  return '';
}
function tokenSequenceIndex(haystack, needle) {
  if (!needle.length || needle.length > haystack.length) return -1;
  outer: for (let i = 0; i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) if (haystack[i + j] !== needle[j]) continue outer;
    return i;
  }
  return -1;
}
function getPageIdentityTokens(item) {
  let pathname = '';
  try { pathname = decodeURIComponent(new URL(String(item && item.url || '')).pathname.split('/').pop() || '').replace(/[-_]+/g, ' '); } catch (_) {}
  return normalizeRequestedVariant([
    item && item.title,
    ...(Array.isArray(item && item.identityHeadings) ? item.identityHeadings : []),
    pathname,
  ].filter(Boolean).join(' ')).split(/\s+/).filter(Boolean);
}
function editionKindsInText(value) {
  const text = String(value || '').toLocaleLowerCase('ru').replace(/ё/g, 'е');
  const tests = [
    ['standard', /\bstandard(?:\s+edition)?\b|\bstandart\b|стандартн|стандарт/iu],
    ['deluxe', /\bdeluxe(?:\s+edition)?\b|делюкс/iu],
    ['ultimate', /\bultimate(?:\s+edition)?\b|ультимативн/iu],
    ['gold', /\bgold(?:\s+edition)?\b|золотое\s+издание/iu],
    ['silver', /\bsilver(?:\s+edition)?\b|серебряное\s+издание/iu],
    ['premium', /\bpremium(?:\s+edition)?\b|премиум/iu],
    ['complete', /\bcomplete(?:\s+edition)?\b|полное\s+издание/iu],
    ['definitive', /\bdefinitive(?:\s+edition)?\b/iu],
    ['goty', /\bgoty\b|game\s+of\s+the\s+year/iu],
    ['base', /\bbase(?:\s+game|\s+edition)?\b|базов(?:ая|ое|ый)\s+(?:игр|верс|издани)/iu],
    ['supporter', /\bsupporter(?:\s+edition)?\b/iu],
    ['vault', /\bvault(?:\s+edition)?\b/iu],
    ['collector', /\bcollector(?:'s)?(?:\s+edition)?\b|коллекционн/iu],
    ['anniversary', /\banniversary(?:\s+edition)?\b|юбилейн/iu],
    ['platinum', /\bplatinum(?:\s+edition)?\b/iu],
    ['remastered', /\bremaster(?:ed)?\b|ремастер/iu],
    ['classic', /\bclassic(?:\s+edition)?\b|классическ/iu],
  ];
  return [...new Set(tests.filter(([, regex]) => regex.test(text)).map(([kind]) => kind))];
}
function descriptionConfirmsFixedEdition(part, item) {
  if (!hasEditionMarker(part) || isLikelyRegionPart(part)) return false;
  const wanted = normalizeRequestedVariant(part).split(/\s+/).filter(Boolean);
  if (wanted.length < 2) return false;
  // This fallback is only used if no actual edition control was discovered.
  // Require the full game + edition phrase in one title/description fragment,
  // and reject fragments that mention competing editions together.
  const sources = [String(item && item.descText || '')].filter(Boolean);
  const targetKinds = editionKindsInText(part);
  if (!targetKinds.length) return false;
  for (const source of sources) {
    const fragments = source.split(/[\r\n]+|[!?;]+|\.\s+/).map(x => x.trim()).filter(x => x.length >= 8 && x.length <= 900);
    for (const fragment of fragments) {
      const words = normalizeRequestedVariant(fragment).split(/\s+/).filter(Boolean);
      if (tokenSequenceIndex(words, wanted) < 0) continue;
      const kinds = editionKindsInText(fragment);
      if (kinds.some(kind => !targetKinds.includes(kind))) continue;
      // Avoid confirming an incidental product mention with no matching game
      // identity; the complete requested phrase must be present in this fragment.
      return true;
    }
  }
  return false;
}
function pageIdentityMatchesPart(part, item) {
  const wanted = normalizeRequestedVariant(part).split(/\s+/).filter(Boolean);
  if (wanted.length < 2 || isLikelyRegionPart(part)) return false;
  const identity = getPageIdentityTokens(item);
  if (tokenSequenceIndex(identity, wanted) >= 0) return true;
  // A few GGSEL titles insert words like "Steam Gift" between the game name and
  // edition. Permit high-confidence overlap only for long, distinctive identity.
  const present = wanted.filter(token => identity.includes(token)).length;
  if (wanted.length >= 4 && present / wanted.length >= 0.85) return true;
  // Some GGSEL cards expose the edition in the seller description rather than
  // in the URL/H1 or as an interactive pill (for example a fixed Standard Edition).
  // Accept that only when the phrase is explicit and no competing edition is named
  // in the same fragment. The caller further restricts this to pages with no edition controls.
  return descriptionConfirmsFixedEdition(part, item);
}
function pageIdentityMatchesGameCore(part, item) {
  if (!hasEditionMarker(part) || isLikelyRegionPart(part)) return false;
  const editionSuffixes = new Set([
    'standard','deluxe','ultimate','premium','basic','complete','definitive','goty',
    'gold','silver','platinum','collector','remastered','anniversary','edition',
    'supporter','classic','base','bundle','pack','expanded','enhanced','special','vault','blackcell','operator','founder'
  ]);
  const wanted = normalizeRequestedVariant(part).split(/\s+/).filter(Boolean);
  while (wanted.length && editionSuffixes.has(wanted[wanted.length - 1])) wanted.pop();
  if (wanted.length >= 2 && wanted[wanted.length - 2] === 'base' && wanted[wanted.length - 1] === 'game') wanted.splice(-2, 2);
  if (wanted.length < 2) return false;
  const identity = getPageIdentityTokens(item);
  if (tokenSequenceIndex(identity, wanted) >= 0) return true;
  const present = wanted.filter(token => identity.includes(token)).length;
  return wanted.length >= 4 && present / wanted.length >= 0.85;
}
function pageIdentityMatchesRegion(part, item) {
  const wanted = normalizeRequestedVariant(part).split(/\s+/).filter(Boolean);
  if (!wanted.length || !isLikelyRegionPart(part)) return false;
  const identity = getPageIdentityTokens(item);
  return tokenSequenceIndex(identity, wanted) >= 0;
}
function isLikelyRegionPart(part) {
  return /(?:росси|russia|\bru\b|укр|украин|ukrain|\bua\b|беларус|снг|\bcis\b|казахстан|kazakhstan|\bkz\b|турци|turkey|turkiye|аргентин|argentina|индия|india|китай|china|таиланд|thailand|бразил|brazil|филиппин|philippin|сша|united states|\busa\b|европ|europe|\beu\b|global|worldwide|любой\s+(?:другой\s+)?регион|any\s+(?:other\s+)?region|снг\s*\+\s*беларус)/i.test(String(part || ''));
}
const REGION_SUFFIX_LABELS = [
  'СНГ+Беларусь', 'СНГ + Беларусь', 'СНГ (БЕЗ РФ И РБ)', 'Турция/Аргентина', 'Турция / Аргентина',
  'Любой другой регион', 'Любой регион', 'Any other region', 'Any region', 'Worldwide', 'Global',
  'СНГ', 'Укр UA', 'Украина', 'Россия', 'РФ', 'Russia', 'Russian', 'RU', 'Беларусь', 'Казахстан', 'Kazakhstan', 'KZ',
  'Турция', 'Turkey', 'Turkiye', 'Аргентина', 'Argentina', 'Индия', 'India', 'Китай', 'China', 'Таиланд', 'Thailand',
  'Бразилия', 'Brazil', 'Филиппины', 'Philippines', 'США', 'USA', 'United States', 'Европа', 'Europe', 'EU', 'UA', 'CIS'
].sort((a, b) => b.length - a.length);
function splitTrailingRegionPart(value) {
  const source = String(value || '').trim();
  for (const label of REGION_SUFFIX_LABELS) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*');
    const match = source.match(new RegExp('(?:\\s+|[+;|]\\s*)(' + escaped + ')\\s*$', 'i'));
    if (!match || match.index == null) continue;
    const base = source.slice(0, match.index).replace(/[\s+;|]+$/, '').trim();
    if (base && isLikelyRegionPart(match[1])) return { base, region: match[1].trim() };
  }
  return null;
}
function staticRegionSupported(part, item) {
  if (!isLikelyRegionPart(part)) return false;
  const sources = [String(item && item.descText || ''), String(item && item.pageText || '')].filter(Boolean);
  const marker = /(?:возможна отправка на следующие регионы|доступные регионы|возможные регионы|страны активации|может быть активирован только в этих странах|активирован только в|регионы активации|можно активировать в|available (?:in|for) the following regions|supported regions|activation regions|can be activated in)/ig;
  const needle = normalizeRequestedVariant(part).split(/\s+/).filter(Boolean);
  for (const source of sources) {
    let match;
    while ((match = marker.exec(source)) !== null) {
      const section = source.slice(match.index, match.index + 1600);
      const normalized = normalizeRequestedVariant(section).split(/\s+/).filter(Boolean);
      if (tokenSequenceIndex(normalized, needle) >= 0) return true;
    }
    marker.lastIndex = 0;
  }
  return false;
}
function hasEditionMarker(value) {
  return /(?:standard|deluxe|ultimate|premium|basic|complete|definitive|goty|gold|silver|platinum|collector|remaster(?:ed)?|anniversary|edition|base\s*(?:game|edition)?|издани|стандарт|делюкс|полное|базов|обычн|расширенн|коллекцион|classic|supporter|season\s*pass|bundle|pack)/i.test(String(value || ''));
}
function findEmbeddedDimensionControls(controls, part) {
  const tokens = normalizeRequestedVariant(part).split(/\s+/).filter(Boolean);
  if (tokens.length < 2) return { controls: [], remainingText: String(part || '').trim() };
  const candidates = [];
  for (const control of (controls || []).filter(isPlausibleVariantControl)) {
    const label = String(control.text || '').trim();
    const labelTokens = normalizeRequestedVariant(label).split(/\s+/).filter(Boolean);
    const type = controlDimension(control);
    if (!labelTokens.length || !type || !['edition', 'region', 'platform'].includes(type)) continue;
    // Avoid taking a game-title fragment as an edition. Embedded edition matches
    // need an edition marker; full exact edition labels were already tried earlier.
    if (type === 'edition' && !hasEditionMarker(label)) continue;
    if (type === 'region' && !isLikelyRegionPart(label)) continue;
    const index = tokenSequenceIndex(tokens, labelTokens);
    if (index < 0) continue;
    candidates.push({ control, label, type, tokens: labelTokens, index,
      priority: (control.inPromptScopedGroup ? 100 : 0) + (control.inPurchaseArea ? 30 : 0) + (control.selected ? 10 : 0) });
  }
  candidates.sort((a, b) => b.tokens.length - a.tokens.length || b.priority - a.priority);
  const chosen = [], usedPositions = new Set(), usedTypes = new Set();
  for (const candidate of candidates) {
    if (usedTypes.has(candidate.type)) continue;
    let overlaps = false;
    for (let i = candidate.index; i < candidate.index + candidate.tokens.length; i++) if (usedPositions.has(i)) overlaps = true;
    if (overlaps) continue;
    chosen.push(candidate);
    usedTypes.add(candidate.type);
    for (let i = candidate.index; i < candidate.index + candidate.tokens.length; i++) usedPositions.add(i);
  }
  if (!chosen.length) return { controls: [], remainingText: String(part || '').trim() };
  const remaining = tokens.filter((_, index) => !usedPositions.has(index));
  return { controls: chosen, remainingText: remaining.join(' ') };
}
function isEditionOnlyResidual(value) {
  // Some GGSEL region controls append the product's base title to the button
  // label. Removing that embedded label can leave only a fixed edition suffix,
  // for example "Vault Edition". Accept only short, recognizable edition names;
  // arbitrary leftover text must still fail closed.
  const text = String(value || '').trim();
  const tokens = normalizeRequestedVariant(text).split(/\s+/).filter(Boolean);
  if (tokens.length < 1 || tokens.length > 4 || !hasEditionMarker(text)) return false;
  if (!editionKindsInText(text).length) return false;
  const allowed = new Set([
    'standard','deluxe','ultimate','premium','basic','complete','definitive','goty',
    'gold','silver','platinum','collector','anniversary','remastered','remaster',
    'classic','supporter','vault','edition','base','game','bundle','pack','expanded',
    'enhanced','special','blackcell','operator','founder','champions','crossgen','cross',
    'gen','upgrade','professional','premium'
  ]);
  return tokens.every(token => allowed.has(token));
}
function embeddedControlConfirmsProductIdentity(entries, item) {
  // GGSEL sometimes embeds the actual game title in parentheses inside every
  // regional button, e.g. "СНГ (БЕЗ РФ И РБ) (Call of Duty: Modern Warfare 4)".
  // Use only those title fragments to confirm which product the control belongs to.
  for (const entry of (entries || [])) {
    const label = String(entry && (entry.label || entry.control && entry.control.text) || '');
    const fragments = [...label.matchAll(/\(([^()]{5,180})\)/g)].map(match => match[1].trim());
    for (const fragment of fragments) {
      const tokens = normalizeRequestedVariant(fragment).split(/\s+/).filter(Boolean);
      if (tokens.length >= 3 && pageIdentityMatchesPart(fragment, item)) return true;
    }
  }
  return false;
}

function pickVariantControl(controls, requested, exactOnly = false) {
  const normalized = normalizeRequestedVariant(requested);
  const wanted = normalized.split(/\s+/).filter(Boolean);
  const scored = [];
  const basic = (value) => String(value || '').toLocaleLowerCase('ru').replace(/ё/g, 'е').replace(/[^\p{L}\p{N}]+/gu, ' ').trim().split(/\s+/).filter(Boolean).join(' ');
  const normalizedBasicRequest = basic(requested);
  const baseAvailable = (controls || []).filter(control => control && control.available !== false && isPlausibleVariantControl(control));
  const requestedIsComposite = /\s+\+\s+|[;|]/.test(String(requested || ''));
  const requestedDimension = requestedIsComposite ? '' : controlDimension({ text: requested });
  // Match a requested part only against selectors of its own dimension.
  // GGSEL region buttons can include a product title such as "Vault Edition"
  // or "Steam Gift" in parentheses; fuzzy matching must not select that region
  // when the parser is trying to select an edition or platform.
  const available = requestedDimension ? baseAvailable.filter(control => {
    const candidateDimension = controlDimension(control);
    if (candidateDimension === requestedDimension) return true;
    return !candidateDimension && normalizeRequestedVariant(control.text) === normalized;
  }) : baseAvailable;
  // Prefer literal normalized text before synonym-based matching. Some GGSEL
  // controls repeat the product name in a wrapper (for example
  // "ASSETTO CORSA ASSETTO CORSA ULTIMATE"). A synonym/token-normalizer must
  // not make that longer wrapper equal to the exact requested edition.
  const literalExactMatches = available.filter(control => basic(control.text) === normalizedBasicRequest);
  if (literalExactMatches.length === 1) {
    return { control: literalExactMatches[0], label: String(literalExactMatches[0].text || '').trim() };
  }
  if (literalExactMatches.length > 1) {
    const labels = [...new Set(literalExactMatches.map(control => String(control.text || '').trim()))];
    if (labels.length === 1) return { control: literalExactMatches[0], label: labels[0] };
    return { error: `Вариант «${requested}» неоднозначен: ${labels.slice(0, 8).join(' / ')}.` };
  }
  const normalizedExactMatches = available.filter(control => normalizeRequestedVariant(control.text) === normalized);
  if (normalizedExactMatches.length === 1) {
    return { control: normalizedExactMatches[0], label: String(normalizedExactMatches[0].text || '').trim() };
  }
  if (normalizedExactMatches.length > 1) {
    const labels = [...new Set(normalizedExactMatches.map(control => String(control.text || '').trim()))];
    if (labels.length === 1) return { control: normalizedExactMatches[0], label: labels[0] };
    return { error: `Вариант «${requested}» неоднозначен: ${labels.slice(0, 8).join(' / ')}.` };
  }
  // The base title can be only a prefix of multiple actual editions, not a control.
  if (!exactOnly && normalizedBasicRequest && wanted.length >= 2) {
    const prefixed = available.filter(control => basic(control.text).startsWith(normalizedBasicRequest + ' '));
    const distinct = [...new Set(prefixed.map(control => basic(control.text)))];
    if (distinct.length >= 2) return { ignored: true, label: requested, reason: `«${requested}» — общее начало нескольких вариантов (${prefixed.slice(0, 6).map(control => control.text).join(' / ')}), а не отдельный переключатель.` };
  }
  for (const control of available) {
    const label = String(control.text || '').trim();
    const candidateBasic = basic(label);
    const candidate = normalizeRequestedVariant(label);
    if (!candidate) continue;
    const tokens = candidate.split(/\s+/);
    let score = -1;
    if (candidateBasic === normalizedBasicRequest) score = 1200;
    else if (candidate === normalized) score = 1000;
    else if (!exactOnly && candidate.includes(normalized)) score = 900;
    else if (!exactOnly && wanted.length && wanted.every(word => tokens.includes(word))) score = 700 + wanted.length;
    if (score >= 0) scored.push({ control, label, score });
  }
  if (!scored.length) return { error: `Вариант «${requested}» не найден среди доступных переключателей.` };
  scored.sort((a, b) => b.score - a.score);
  const highest = scored.filter(x => x.score === scored[0].score);
  if (highest.length > 1) return { error: `Вариант «${requested}» неоднозначен: ${highest.slice(0, 8).map(x => x.label).join(' / ')}.` };
  return { control: highest[0].control, label: highest[0].label };
}

async function collectListing(context, marketplace, pid, urlBuilder) {
  const url = urlBuilder(pid);
  const page = await context.newPage();
  page.setDefaultTimeout(PAGE_TIMEOUT_MS);
  const out = { marketplace, pid, url, title: '', template: '', initialPrices: [], pageText: '', descText: '', skippedControls: [], options: [], error: null };
  try {
    const navigationResponse = await withTimeout(page.goto(url, { waitUntil: 'domcontentloaded', timeout: PAGE_TIMEOUT_MS }), PAGE_TIMEOUT_MS + 5000, 'goto');
    out.httpStatus = navigationResponse && typeof navigationResponse.status === 'function' ? navigationResponse.status() : null;
    await sleep(1800);
    out.title = await page.title();
    if (marketplace === 'ggsel') {
      const availability = await page.evaluate(() => {
        const title = String(document.title || '');
        const headings = Array.from(document.querySelectorAll('h1,h2,[role="alert"]')).slice(0, 12).map(el => (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim()).filter(Boolean);
        const firstText = String(document.body && document.body.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 2200);
        const buyButtons = Array.from(document.querySelectorAll('button,[role="button"]'))
          .filter(el => /купить|buy|заказать|нет\s+в\s+наличии/i.test(String(el.innerText || el.textContent || '')))
          .slice(0, 8).map(el => ({ text: String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim(), disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true' }));
        // Кнопка покупки в блоке товара — надёжный признак отсутствия товара.
        // Текст «Нет в наличии» после гидрации исчезает из body, но сама
        // заблокированная кнопка остаётся.
        const buyButton = Array.from(document.querySelectorAll(
          '[data-testid="product-button"], [class*="ProductBuyBlock"] button, [class*="ProductBuyBlock"] a, [class*="BuyBlock"] button'
        )).find(el => /купить|buy|заказать|нет\s+в\s+наличии/i.test(String(el.innerText || el.textContent || ''))) || null;
        const buyButtonDisabled = buyButton
          ? (!!buyButton.disabled || buyButton.getAttribute('aria-disabled') === 'true' || /нет\s+в\s+наличии/i.test(String(buyButton.innerText || buyButton.textContent || '')))
          : false;
        const buyButtonText = buyButton ? String(buyButton.innerText || buyButton.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80) : '';
        return { title, headings, firstText, buyButtons, buyButtonDisabled, buyButtonText };
      }).catch(() => ({ title: out.title, headings: [], firstText: '', buyButtonDisabled: false, buyButtonText: '' }));
      const unavailableText = [availability.title, ...(availability.headings || []), availability.firstText].join(' ');
      const notFound = /(?:товар|лот|страница)\s+(?:не найден(?:а|о)?|не существу(?:ет|ют)|удал[её]н(?:а|о)?|снят[ао]?\s+с\s+продажи|больше\s+недоступен)|(?:не найден(?:а|о)?|не существу(?:ет|ют))\s+(?:товар|лот|страница)|(?:product|listing)\s+(?:not found|has been removed)|page\s+not\s+found|no\s+longer\s+available/i.test(unavailableText);
      const explicitUnavailable = /(?:нет\s+в\s+наличии|товар\s+закончился|распродан|нет\s+остатка|недоступен\s+для\s+покупки|sold\s*out|out\s*of\s*stock|currently\s+unavailable)/i.test(unavailableText) ||
        (Array.isArray(availability.buyButtons) && availability.buyButtons.length > 0 && availability.buyButtons.every(button => button.disabled)) ||
        Boolean(availability.buyButtonDisabled);
      // HTTP denial pages can contain generic text that resembles an availability
      // notice. Classify denial first; only a real product response (200) can be
      // marked as out of stock based on page content.
      if ([401, 402, 403].includes(Number(out.httpStatus)) || /^HTTP\s+40[123]\b/i.test(String(out.title || ''))) {
        out.error = `GGSEL отклонил запрос автоматического браузера (HTTP ${out.httpStatus || String(out.title).replace(/\D/g, '') || '401/403'}). Обнови открытую страницу GGSEL в Firefox и повтори парсинг, чтобы обновить cookies антибот-защиты.`;
        return out;
      }
      // A product page can render "Нет в наличии" for the DEFAULT/unselected variant
      // while a requested variant is actually in stock (e.g. selected region edition).
      // When a variant is requested, defer the availability decision until after
      // variant selection so a real in-stock edition is not misreported as unavailable.
      if (out.httpStatus === 404 || out.httpStatus === 410 || notFound) {
        out.listingUnavailable = true;
        out.listingDeleted = true;
        out.error = 'Лот GGSEL удалён или больше не существует' + (out.httpStatus === 404 || out.httpStatus === 410 ? ` (HTTP ${out.httpStatus})` : '') + '.';
        return out;
      }
      if (out.httpStatus === 200 && explicitUnavailable && !VARIANT_HINT) {
        out.listingUnavailable = true;
        out.error = 'Товар GGSEL сейчас не в наличии или недоступен для покупки.';
        return out;
      }
      out.defaultUnavailable = Boolean(explicitUnavailable);
    }
    await sleep(700);
    out.template = await detectTemplate(page);
    out.initialPrices = await snapshotPrices(page);
    const inventory = await collectVariantControls(page, marketplace === 'ggsel' ? VARIANT_HINT : '');
    const scopedControls = marketplace === 'ggsel' && Array.isArray(inventory.scopedControls)
      ? inventory.scopedControls.filter(isPlausibleVariantControl) : [];
    const usePromptScopedControls = scopedControls.length > 0;
    const rawControls = usePromptScopedControls ? scopedControls : inventory.controls;
    // Repair stale/cached composite variant labels against the current product page.
    // Long description text and seller recommendations must never be treated as options.
    const controls = (rawControls || []).filter(isPlausibleVariantControl);
    const skipped = inventory.skipped || [];
    out.variantScope = usePromptScopedControls ? 'prompt-scoped' : 'page-wide-fallback';
    out.skippedControls = skipped;

    // GGSEL variant discovery is inventory-only: read the available control
    // labels and exit. Do not click options, wait for each price or retry them.
    if (marketplace === 'ggsel' && FAST_GGSEL) {
      out.options = controls.map(ctrl => Object.assign({}, ctrl, {
        clicked: false, prices: [], priceVerified: false,
        selected: Boolean(ctrl.selected), selectedAfter: Boolean(ctrl.selected)
      }));
      out.controlCount = controls.length;
      out.controlsClicked = 0;
      if (DISCOVER_ONLY || !VARIANT_HINT) {
        // Default-price parsing uses the initial active buy box. Requested-variant
        // parsing below clicks only the chosen control(s), never the entire page.
        if (!DISCOVER_ONLY) {
          out.pageText = await grabPageText(page);
          out.descText = await grabDescText(page);
          out.identityHeadings = await grabIdentityHeadings(page);
        }
        return out;
      }
      out.pageText = await grabPageText(page);
      out.descText = await grabDescText(page);
      out.identityHeadings = await grabIdentityHeadings(page);
    } else {
      out.pageText = await grabPageText(page);
      out.descText = await grabDescText(page);
    }

    // Plati still needs the full control sweep. GGSEL skips it above and only
    // selects the exact requested edition/region below when one was supplied.
    const orderedControls = (marketplace === 'ggsel' && FAST_GGSEL) ? [] : controls.slice().sort((a, b) => Number(a.selected) - Number(b.selected));
    for (const ctrl of orderedControls) {
      if (ctrl.available === false) {
        out.options.push(Object.assign({}, ctrl, { clicked: false }));
        continue;
      }
      const beforePrices = await snapshotPrices(page);
      let clicked = false;
      let wasSelected = false;
      try {
        wasSelected = await controlIsSelected(page, ctrl);
        // Don't blindly re-click an option that is already selected. On reactive
        // pages that can reset the sibling selector or leave an old price behind.
        clicked = wasSelected || await withTimeout(clickControl(page, ctrl), CLICK_TIMEOUT_MS, 'click');
      } catch (e) {
        out.options.push(Object.assign({}, ctrl, { clicked: false, err: String(e.message || e) }));
        continue;
      }
      if (!clicked) {
        out.options.push(Object.assign({}, ctrl, { clicked: false }));
        continue;
      }
      const settled = await waitForSettledPrices(page, beforePrices, wasSelected);
      const selectedAfter = await controlIsSelected(page, ctrl);
      out.options.push(Object.assign({}, ctrl, {
        clicked: true,
        beforePrices,
        prices: settled.prices,
        priceChanged: settled.changed,
        priceStable: settled.stable,
        selected: selectedAfter,
        selectedAfter,
        // A cached/default price is only trustworthy when the option is still
        // selected and the active price has settled; changed options must show
        // a real buy-box price transition.
        priceVerified: settled.prices.length > 0 && settled.stable && (Boolean(ctrl.selected) || selectedAfter),
        priceSettleMs: settled.elapsedMs,
      }));
    }
    // Re-select the exact requested edition/region after inventorying all controls.
    // A value such as "Standard + EU" must select both controls before reading final price.
    if (marketplace === 'ggsel' && VARIANT_HINT) {
      const selectedControls = [];
      const fixedVariantParts = [];
      const requestedHasSeparator = /\s+\+\s+|[;|]/.test(VARIANT_HINT);
      // First try an exact combined option. If the saved value is a legacy composite
      // without separators ("Edition Russia"), split it by real page controls and
      // the product's own identity instead of treating the whole string as one option.
      const combinedPick = pickVariantControl(controls, VARIANT_HINT, requestedHasSeparator);
      let requestedParts = splitRequestedVariant(VARIANT_HINT);
      if (combinedPick.ignored) {
        out.requestedVariantError = `Часть «${VARIANT_HINT}» неоднозначна: она совпадает с общим названием нескольких изданий. Выбери конкретное издание.`;
      } else if (!combinedPick.error) {
        selectedControls.push(combinedPick);
        out.variantAutoRepair = { strategy: 'exact-combined-option', requested: VARIANT_HINT };
      } else {
        let strategy = requestedHasSeparator ? 'explicit-dimensions' : 'auto-split-and-verify';
        if (requestedParts.length === 1) {
          const suffix = splitTrailingRegionPart(VARIANT_HINT);
          if (suffix) requestedParts = [suffix.base, suffix.region];
        }
        out.variantAutoRepair = { strategy, requested: VARIANT_HINT, parts: requestedParts.slice() };
        for (const part of requestedParts) {
          // The game name (e.g. "Fallout 4") is an identity fragment, not a selector.
          // Handle it before fuzzy control matching so a broad seller/page wrapper cannot match it.
          const partDimension = controlDimension({ text: part });
          if (!partDimension && pageIdentityMatchesPart(part, out)) {
            fixedVariantParts.push(part);
            out.variantAutoRepair = { ...(out.variantAutoRepair || {}), identityMatchedPart: part };
            continue;
          }
          const pick = pickVariantControl(controls, part);
          if (pick.ignored) {
            out.requestedVariantError = `Вариант «${part}» неоднозначен: ${pick.reason || 'он является общим названием нескольких изданий'}. Укажи конкретное издание.`;
            break;
          }
          if (!pick.error) {
            const dimension = controlDimension(pick.control);
            const duplicate = selectedControls.some(x =>
              String(x.control.text || '').trim() === String(pick.control.text || '').trim() &&
              controlDimension(x.control) === dimension
            );
            if (!duplicate) selectedControls.push(pick);
            continue;
          }
          // Auto-repair #1: recover individual edition/platform/region controls
          // that are embedded in a legacy composite label without separators.
          const embedded = findEmbeddedDimensionControls(controls, part);
          if (embedded.controls.length) {
            for (const entry of embedded.controls) {
              const duplicate = selectedControls.some(x =>
                String(x.control.text || '').trim() === String(entry.control.text || '').trim() &&
                controlDimension(x.control) === entry.type
              );
              if (!duplicate) selectedControls.push({ control: entry.control, label: entry.label });
            }
            if (!embedded.remainingText) continue;
            if (pageIdentityMatchesPart(embedded.remainingText, out)) {
              // The leftover is the product identity, not another selectable option.
              // The actual edition/platform choice is already represented by the
              // matched control labels; do not report a normalized title as a variant.
              out.variantAutoRepair.identityMatched = embedded.remainingText;
              continue;
            }
            const editionControlsForEmbedded = controls.filter(control =>
              control.available !== false && controlDimension(control) === 'edition'
            );
            if (
              isEditionOnlyResidual(embedded.remainingText) &&
              editionControlsForEmbedded.length === 0 &&
              embeddedControlConfirmsProductIdentity(embedded.controls, out)
            ) {
              // The page exposes the product identity only inside the region option,
              // while the requested edition is a fixed SKU descriptor (e.g. Vault Edition).
              // With no selectable edition control to choose, retain that descriptor as
              // fixed metadata and select the verified region control instead of failing.
              fixedVariantParts.push(embedded.remainingText);
              out.variantAutoRepair = {
                ...(out.variantAutoRepair || {}),
                fixedEditionConfirmedBy: 'embedded-region-product-identity-no-edition-selector',
                fixedEdition: embedded.remainingText,
              };
              continue;
            }
            out.requestedVariantError = `Автоисправление нашло переключатель «${embedded.controls.map(x => x.label).join(' + ')}», но остаток «${embedded.remainingText}» не совпадает с названием товара.`;
            break;
          }
          // Accept it only when the current page title/H1/slug independently confirms it.
          const actualEditionControls = controls.filter(control =>
            control.available !== false && controlDimension(control) === 'edition'
          );
          // A variant can be a fixed edition of the linked GGSEL product rather
          // than a clickable option. If the page exposes no edition selector,
          // confirm the saved edition against the product identity: either the full
          // edition appears in URL/title/H1/description, or the game's distinctive
          // core matches the linked product while the edition is fixed by this SKU.
          // If actual edition controls exist, never bypass them or guess between editions.
          if (actualEditionControls.length === 0 &&
              (pageIdentityMatchesPart(part, out) || pageIdentityMatchesGameCore(part, out))) {
            fixedVariantParts.push(part);
            out.variantAutoRepair = {
              ...(out.variantAutoRepair || {}),
              fixedEditionConfirmedBy: pageIdentityMatchesPart(part, out) ? 'product-identity' : 'game-identity-no-edition-selector',
            };
            continue;
          }
          // Auto-repair #3: some listings describe supported regions but have no actual
          // region control. Accept it only if the explicit availability section and the
          // current product URL/title independently identify that same region.
          const actualRegionControls = controls.filter(control =>
            control.available !== false && controlDimension(control) === 'region'
          );
          // If the card has no selectable region controls, an explicit availability
          // list is authoritative for compatibility. The page's active price is fixed
          // for all listed regions, so don't require the region to be in the URL slug.
          if (actualRegionControls.length === 0 && (staticRegionSupported(part, out) || pageIdentityMatchesRegion(part, out))) {
            fixedVariantParts.push(part);
            continue;
          }
          out.requestedVariantError = `Вариант «${part}» не найден среди доступных переключателей и не подтверждён названием/описанием товара.`;
          break;
        }
        if (!out.requestedVariantError) {
          const requestedHasEdition = requestedParts.some(part => mentionsEdition(part)) || selectedControls.some(pick => mentionsEdition(pick.label) || controlDimension(pick.control) === 'edition');
          const availableEditions = controls.filter(control => control.available !== false && controlDimension(control) === 'edition');
          if (!requestedHasEdition && availableEditions.length > 1 && !selectedControls.some(pick => controlDimension(pick.control) === 'edition')) {
            const selectedEditions = availableEditions.filter(control => control.selected === true);
            if (selectedEditions.length === 1) {
              selectedControls.push({ control: selectedEditions[0], label: String(selectedEditions[0].text || '').trim() });
              out.variantAutoRepair = { ...(out.variantAutoRepair || {}), selectedCurrentEditionUsed: String(selectedEditions[0].text || '').trim() };
            } else {
              out.requestedVariantError = `Для «${VARIANT_HINT}» GGSEL показывает несколько изданий (${availableEditions.map(control => String(control.text || '').trim()).filter(Boolean).join(', ')}), но вариант не указывает издание. Укажи его явно, например «Fallout 4 Standard Россия» или «Fallout 4 GOTY Россия».`;
            }
          }
          if (!out.requestedVariantError && selectedControls.length === 0 && fixedVariantParts.length === 0) {
            out.requestedVariantError = `Не найдено ни одного однозначного переключателя для варианта «${VARIANT_HINT}». Автопроверка не смогла подтвердить издание или регион.`;
          }
        }
        if (!out.requestedVariantError) {
          out.variantAutoRepair = {
            ...(out.variantAutoRepair || {}),
            matchedControls: selectedControls.map(x => x.label),
            verifiedFixedParts: fixedVariantParts.slice(),
          };
        }
      }
      if (!out.requestedVariantError) {
        const byDimension = new Map();
        for (const pick of selectedControls) {
          const dimension = controlDimension(pick.control);
          if (!dimension) continue;
          const key = normalizeRequestedVariant(pick.label || pick.control.text || '');
          const previous = byDimension.get(dimension);
          if (previous && previous.key !== key) {
            out.requestedVariantError = `Вариант «${VARIANT_HINT}» сопоставился с несколькими значениями одного параметра (${dimension}: «${previous.label}» и «${pick.label}»). Цена не будет сохранена, чтобы не взять стоимость другого издания/региона.`;
            break;
          }
          byDimension.set(dimension, { key, label: pick.label || pick.control.text || '' });
        }
      }
      if (!out.requestedVariantError) {
        let selectionOk = true;
        const controlsToVerifyAfterAllSelections = [];
        for (const pick of selectedControls) {
          const before = await snapshotPrices(page);
          try {
            const optionType = String(pick.control.type || '').toLowerCase();
            const optionsInDimension = optionType
              ? controls.filter(control => String(control.type || '').toLowerCase() === optionType && control.available !== false)
              : [];
            // Some GGSEL listings expose one fixed edition only (e.g. a single
            // "EA SPORTS FC 26" pill). It is already the only possible choice;
            // clicking it is unnecessary and its visual selected state is not
            // always exposed via ARIA/classes. Confirm the requested label matches
            // the sole option, then leave it intact and move on to the region.
            const isSoleFixedOption = ['edition', 'region', 'platform'].includes(optionType)
              && optionsInDimension.length === 1
              && String(optionsInDimension[0].text || '').trim() === String(pick.control.text || '').trim();
            if (isSoleFixedOption) {
              out.fixedVariantDimensions = out.fixedVariantDimensions || [];
              out.fixedVariantDimensions.push({ type: optionType, label: pick.label, reason: 'единственный доступный вариант этой группы' });
              continue;
            }
            const wasSelected = await controlIsSelected(page, pick.control);
            // При запросе конкретного варианта всегда кликаем на контрол, даже если он
            // уже визуально выбран: SSR-состояние может не совпадать с реальным после
            // гидрации, и без клика цена buy-блока не обновится.
            const mustClick = Boolean(VARIANT_HINT) || !wasSelected;
            if (mustClick) {
              const clicked = await withTimeout(clickControl(page, pick.control), CLICK_TIMEOUT_MS, 'requested variant click');
              if (!clicked) { selectionOk = false; out.requestedVariantError = `Не удалось выбрать вариант «${pick.label}».`; break; }
            }
            const settled = await waitForSettledPrices(page, before, wasSelected, pick.control);
            const selectedAfter = await controlIsSelected(page, pick.control);
            if (!selectedAfter) {
              // A successful click that changes the active buy-box price is
              // independent evidence that GGSEL applied this control, even if
              // the page uses a visual state that is not exposed in the DOM.
              // If price did not change, do not infer selection from stability alone.
              if (!(settled.stable && settled.changed)) {
                selectionOk = false; out.requestedVariantError = `GGSEL не подтвердил выбор варианта «${pick.label}».`; break;
              }
            }
            // A stable active buy-box snapshot is still required. Equal prices are
            // legitimate; the control state or a real price transition confirms the choice.
            if (!settled.stable) {
              selectionOk = false;
              out.requestedVariantError = `Цена после выбора «${pick.label}» не стабилизировалась.`;
              break;
            }
            controlsToVerifyAfterAllSelections.push(pick);
          } catch (e) {
            selectionOk = false; out.requestedVariantError = `Ошибка выбора варианта «${pick.label}»: ${String(e.message || e)}`; break;
          }
        }
        await sleep(500);
        // Selecting one GGSEL parameter can reset another parameter in the
        // reactive buy box. Validate the final combined selection before reading
        // a price; fail closed instead of saving the price of a different SKU.
        if (selectionOk && controlsToVerifyAfterAllSelections.length > 1) {
          const finalChecks = [];
          for (const pick of controlsToVerifyAfterAllSelections) {
            const stillSelected = await controlIsSelected(page, pick.control);
            finalChecks.push({ label: pick.label, selected: stillSelected, dimension: controlDimension(pick.control) || '' });
            if (!stillSelected) {
              selectionOk = false;
              out.requestedVariantError = `После выбора остальных параметров GGSEL сбросил вариант «${pick.label}». Цена не сохранена, чтобы не записать стоимость другого издания/региона. Проверь сочетание на странице товара.`;
              break;
            }
          }
          out.requestedVariantFinalSelectionChecks = finalChecks;
        }
        const finalPrices = await snapshotPrices(page);
        // После выбора варианта проверяем кнопку покупки: если она заблокирована,
        // товара нет и для выбранного варианта — цена показываться не должна.
        const buyState = await page.evaluate(() => {
          const button = Array.from(document.querySelectorAll(
            '[data-testid="product-button"], [class*="ProductBuyBlock"] button, [class*="ProductBuyBlock"] a, [class*="BuyBlock"] button'
          )).find(el => /купить|buy|заказать|нет\s+в\s+наличии/i.test(String(el.innerText || el.textContent || ''))) || null;
          if (!button) return { present: false, disabled: false, text: '' };
          return {
            present: true,
            disabled: !!button.disabled || button.getAttribute('aria-disabled') === 'true' || /нет\s+в\s+наличии/i.test(String(button.innerText || button.textContent || '')),
            text: String(button.innerText || button.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80),
          };
        }).catch(() => ({ present: false, disabled: false, text: '' }));
        if (buyState.present && buyState.disabled) {
          out.listingUnavailable = true;
          out.defaultUnavailable = true;
          out.error = 'Товар GGSEL сейчас не в наличии или недоступен для покупки.';
          out.requestedVariantVerified = false;
          out.requestedVariantError = 'Товара нет в наличии для выбранного варианта.';
        }
        out.requestedVariant = VARIANT_HINT;
        const confirmedLabels = [...selectedControls.map(x => x.label), ...fixedVariantParts];
        const normalizedRequestForOrder = normalizeRequestedVariant(VARIANT_HINT);
        confirmedLabels.sort((a, b) => {
          const aa = normalizeRequestedVariant(a), bb = normalizeRequestedVariant(b);
          const ai = aa ? normalizedRequestForOrder.indexOf(aa) : -1;
          const bi = bb ? normalizedRequestForOrder.indexOf(bb) : -1;
          return (ai < 0 ? 9999 : ai) - (bi < 0 ? 9999 : bi);
        });
        out.requestedVariantSelections = confirmedLabels;
        out.requestedVariantPriceSnapshot = finalPrices;
        const activePrice = finalPrices.some(p => {
          if (!p || p.visible === false || p.struckThrough === true || String(p.priceRole || '').toLowerCase() === 'old' || !/\d/.test(String(p.text || ''))) return false;
          // Any visible price with digits is acceptable for a requested variant.
          // GGSEL markup varies by product; don't require the price to live in the
          // buy box or carry a specific CSS class.
          return true;
        });
        out.requestedVariantVerified = selectionOk && (selectedControls.length > 0 || fixedVariantParts.length > 0) && activePrice && !out.listingUnavailable;
        if (!out.requestedVariantVerified && !out.requestedVariantError) {
          const priceDiagnostics = finalPrices
            .filter(p => p && p.visible !== false && /\d/.test(String(p.text || '')))
            .slice(0, 10)
            .map(p => String(p.text || '').trim() + (p.inBuyBlock ? ' [блок покупки]' : ' [вне блока покупки]'));
          out.requestedVariantError = 'После выбора варианта GGSEL не удалось подтвердить цену.' +
            (priceDiagnostics.length ? ' Цены в снимке: ' + priceDiagnostics.join('; ') : ' В снимке не найдена видимая цена в рублях.');
        }
      }
    }
    out.controlCount = controls.length;
    out.controlsClicked = out.options.filter((o) => o.clicked).length;
  } catch (e) {
    out.error = String(e.message || e);
  } finally {
    try { await page.close(); } catch (e) {}
  }
  return out;
}

async function runWorker(workerId, queue, context, onDone) {
  while (queue.length > 0) {
    const job = queue.shift();
    if (!job) break;
    const t0 = Date.now();
    process.stderr.write(`[w${workerId}] ${job.marketplace} ${String(job.pid).slice(0, 50)}...\n`);
    try {
      let result;
      const retryReasons = [];
      let captureAttempts = 0;
      for (let attempt = 0; attempt <= CAPTURE_RETRIES; attempt++) {
        captureAttempts = attempt + 1;
        result = await collectListing(context, job.marketplace, job.pid, job.urlBuilder);
        const reasons = [];
        if (result.error) reasons.push('listing error');
        // GGSEL only selects the requested option; untouched sibling options are
        // inventory, not failures. Never re-open the same GGSEL page for a sweep.
        if (!(job.marketplace === 'ggsel' && FAST_GGSEL)) {
          for (const option of result.options || []) {
            if (option.available !== false && option.clicked !== true) reasons.push('available control not clicked');
            if (option.clicked && (!option.prices || option.prices.length === 0)) reasons.push('missing price snapshot');
            if (option.priceChanged && !option.priceStable) reasons.push('unstable changed price');
          }
        }
        const variantIsAmbiguous = Boolean(result.requestedVariantError) &&
          /неоднознач|общее название нескольких изданий/i.test(String(result.requestedVariantError));
        const retryFastVariantResolution = job.marketplace === 'ggsel' && FAST_GGSEL && Boolean(VARIANT_HINT) &&
          attempt < CAPTURE_RETRIES && !variantIsAmbiguous && !result.listingUnavailable && (
            Boolean(result.error) || Boolean(result.requestedVariantError) || result.requestedVariantVerified !== true
          );
        if (retryFastVariantResolution) {
          retryReasons.push('GGSEL variant auto-recovery');
          process.stderr.write(`[w${workerId}] ${job.marketplace} ${String(job.pid).slice(0, 50)} — retry ${attempt + 1}/${CAPTURE_RETRIES}: re-open page and re-resolve requested variant\n`);
          await sleep(650 * (attempt + 1));
          continue;
        }
        if (reasons.length === 0 || attempt === CAPTURE_RETRIES || (job.marketplace === 'ggsel' && FAST_GGSEL)) break;
        retryReasons.push(...reasons);
        process.stderr.write(`[w${workerId}] ${job.marketplace} ${String(job.pid).slice(0, 50)} — retry ${attempt + 1}/${CAPTURE_RETRIES}: ${[...new Set(reasons)].join(', ')}\n`);
      }
      result.captureAttempts = captureAttempts;
      result.captureRetryReasons = [...new Set(retryReasons)];
      onDone(result);
      process.stderr.write(`[w${workerId}] ${job.marketplace} ${String(job.pid).slice(0, 50)} — ${result.controlsClicked || 0}/${result.controlCount || 0} clicked in ${Date.now() - t0}ms\n`);
    } catch (e) {
      onDone({ marketplace: job.marketplace, pid: job.pid, url: job.urlBuilder(job.pid), error: String(e.message || e) });
      process.stderr.write(`[w${workerId}] ${job.marketplace} ${String(job.pid).slice(0, 50)} — FAIL in ${Date.now() - t0}ms: ${e.message}\n`);
    }
  }
}

(async () => {
  const remoteBrowser = Boolean(CDP_URL);
  const launchOptions = {
    headless: HEADLESS,
    args: ['--no-sandbox', '--disable-blink-features=AutomationControlled'],
  };
  // Use a caller-provided Chrome path only when configured; otherwise Playwright's bundled browser.
  if (CHROME_PATH) launchOptions.executablePath = CHROME_PATH;
  const browser = remoteBrowser
    ? await chromium.connectOverCDP(CDP_URL)
    : await chromium.launch(launchOptions);
  const remoteContexts = remoteBrowser ? browser.contexts() : [];
  if (remoteBrowser && remoteContexts.length === 0) {
    throw new Error('CDP browser has no usable context');
  }
  const queue = [
    ...[...new Set(PLATI_PIDS)].map((pid) => ({
      marketplace: 'plati', pid,
      urlBuilder: (p) => `https://plati.market/itm/${p}`,
    })),
    ...[...new Set(GGSEL_IDS)].map((id) => ({
      marketplace: 'ggsel', pid: id,
      urlBuilder: (p) => String(GGSEL_URL_MAP[String(p)] || `https://ggsel.net/catalog/product/${p}`),
    })),
  ];
  // A real browser context owns live user tabs, so keep CDP collection
  // sequential. Isolated collection remains parallel.
  const workerCount = remoteBrowser ? 1 : WORKERS;
  const chromeVersion = browser.version();
  const workers = [];
  for (let i = 0; i < workerCount; i++) {
    const ctx = remoteBrowser ? remoteContexts[0] : await browser.newContext({
      locale: 'ru-RU',
      userAgent: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeVersion} Safari/537.36`,
    });
    if (!remoteBrowser) {
      if (GGSEL_COOKIES.length) {
        try { await ctx.addCookies(GGSEL_COOKIES); }
        catch (e) { process.stderr.write(`[w${i}] Could not apply GGSEL browser cookies: ${String(e.message || e).slice(0, 180)}\n`); }
      }
      await ctx.addInitScript(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      });
    }
    workers.push(runWorker(i, queue, ctx, appendListing));
  }
  await Promise.all(workers);
  const final = JSON.parse(fs.readFileSync(OUT_PATH, 'utf8'));
  final.finishedAt = new Date().toISOString();
  fs.writeFileSync(OUT_PATH, JSON.stringify(final, null, 2));
  process.stderr.write(`DONE: ${final.listings.length} listings → ${OUT_PATH}\n`);
  if (!remoteBrowser) await browser.close();
  process.exit(0);
})().catch((e) => {
  process.stderr.write(`FATAL: ${e.stack || e}\n`);
  process.exit(1);
});
